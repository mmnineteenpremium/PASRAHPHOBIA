local Controller = {}
Controller.__index = Controller

local function resolveEventBus(deps)
    local eventBus = deps.EventBus
    if type(eventBus) ~= "table" then
        return nil
    end
    if type(eventBus.Subscribe) == "function" then
        return eventBus
    end
    if type(eventBus.Service) == "table" and type(eventBus.Service.Subscribe) == "function" then
        return eventBus.Service
    end
    return nil
end

function Controller.new(state, service, deps)
    local self = setmetatable({}, Controller)
    self._state = state
    self._service = service
    self._deps = deps or {}
    self._eventBus = resolveEventBus(self._deps)
    self._subscriptions = {}
    return self
end

function Controller:Init()
    -- zone-level wiring happens externally.
end

function Controller:RegisterEventHandlers()
    if not self._eventBus then
        return
    end
    local function handle(payload)
        local player = payload and payload.player
        local percent = payload and payload.performancePercent or 0
        self._service:GrantMatchReward(player, percent)
    end
    self._eventBus:Subscribe("MatchEnded", handle)
    table.insert(self._subscriptions, { eventName = "MatchEnded", callback = handle })
    self._eventBus:Subscribe("ResultsCalculated", handle)
    table.insert(self._subscriptions, { eventName = "ResultsCalculated", callback = handle })
end

function Controller:UnregisterEventHandlers()
    if not self._eventBus then
        return
    end
    for _, sub in ipairs(self._subscriptions) do
        self._eventBus:Unsubscribe(sub.eventName, sub.callback)
    end
    table.clear(self._subscriptions)
end

return Controller
