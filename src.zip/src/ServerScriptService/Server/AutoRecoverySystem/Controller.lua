local Services = require(script.Parent.Parent.Core.Services)

local Controller = {}
Controller.__index = Controller

local function resolveEventBus(deps)
    local eventBus = Services.Get(deps, "EventBus")
    if type(eventBus) ~= "table" then
        return nil
    end
    if type(eventBus.Subscribe) == "function" then
        return eventBus
    end
    if type(eventBus.Service) == "table" and type(eventBus.Service.Subscribe) == "function" then
        return eventBus.Service
    end
    return nil
end

function Controller.new(state, service, deps)
    local self = setmetatable({}, Controller)
    self._state = state
    self._service = service
    self._deps = deps or {}
    self._eventBus = nil
    self._subscriptions = {}
    self._registered = false
    return self
end

function Controller:Create()
    self._eventBus = resolveEventBus(self._deps)
end

function Controller:Init()
    -- Subscriptions are registered in Start.
end

function Controller:Start()
    self:RegisterEventHandlers()
end

function Controller:Stop()
    self:UnregisterEventHandlers()
end

function Controller:RegisterEventHandlers()
    if not self._eventBus or self._registered then
        return
    end

    self:_subscribe("MatchStarted", function(payload)
        self._service:HandleEvent("MatchStarted", payload)
    end)

    self:_subscribe("MatchEnded", function(payload)
        self._service:HandleEvent("MatchEnded", payload)
    end)

    self:_subscribe("PlayerJoinedLobby", function(payload)
        self._service:HandleEvent("PlayerJoinedLobby", payload)
    end)

    self:_subscribe("PlayerDisconnected", function(payload)
        self._service:HandleEvent("PlayerDisconnected", payload)
    end)

    self:_subscribe("SystemErrorDetected", function(payload)
        self._service:HandleEvent("SystemErrorDetected", payload)
    end)

    self._registered = true
end

function Controller:UnregisterEventHandlers()
    if not self._eventBus or not self._registered then
        return
    end
    for _, sub in ipairs(self._subscriptions) do
        self._eventBus:Unsubscribe(sub.eventName, sub.callback)
    end
    table.clear(self._subscriptions)
    self._registered = false
end

function Controller:_subscribe(eventName, callback)
    self._eventBus:Subscribe(eventName, callback)
    table.insert(self._subscriptions, {
        eventName = eventName,
        callback = callback,
    })
end

return Controller