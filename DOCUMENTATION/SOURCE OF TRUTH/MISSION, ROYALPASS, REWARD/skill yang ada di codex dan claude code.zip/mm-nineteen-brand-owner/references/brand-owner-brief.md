# Brand Owner Brief

## Core Structure

- Brand objective
- Current status
- Key risk or opportunity
- Decision required
- Recommended next move
