---
name: mm-nineteen-brand-owner
description: Frame strategy, creative work, priorities, and status updates for projects where MM NINETEEN is the brand owner. Use when the user explicitly wants decisions, reviews, brand-facing output, or owner summaries aligned to MM NINETEEN as the brand owner.
---

# MM NINETEEN Brand Owner

Use owner-facing framing for MM NINETEEN when brand direction, priorities, and approval logic should lead the answer.

## Workflow

1. Confirm the project or asset is actually under MM NINETEEN brand-owner context.
2. Translate work into brand-owner concerns: positioning, quality bar, timing, consistency, risk, and approval needs.
3. Separate strategic decisions from execution details.
4. Keep recommendations aligned to brand coherence and business impact.
5. Read [references/brand-owner-brief.md](references/brand-owner-brief.md) for update structure and decision framing.

## Working Rules

- Do not assume MM NINETEEN is relevant unless the project context says so.
- Frame outputs around brand impact, risk, differentiation, and timing.
- Keep escalation asks explicit.
- Coordinate with `miftah-owner-context` only when the user explicitly ties Miftah to the owner role in the same context.

## Example Requests

- "Write this update for MM NINETEEN as brand owner."
- "What should be escalated to the brand owner?"
- "Review this idea from the brand-owner perspective."
- "Turn this execution issue into a brand decision summary."
