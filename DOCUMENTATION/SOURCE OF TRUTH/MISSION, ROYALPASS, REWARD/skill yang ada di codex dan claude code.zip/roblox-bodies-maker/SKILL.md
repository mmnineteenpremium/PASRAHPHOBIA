---
name: roblox-bodies-maker
description: Use for Roblox avatar body and head creation, R15 body packages, dynamic heads, skinned meshes, body part separation, attachments, cage/wrap validation, Avatar Setup, body scaling, face/body textures, Marketplace body readiness, and troubleshooting avatar body import or validation failures.
---

# Roblox Bodies Maker

Use this skill for avatar bodies, heads, and body packages.

## Workflow

1. Confirm target: in-game character body, Marketplace avatar body, dynamic head, static head, or NPC body.
2. Design body proportions, silhouette, style, texture approach, and compatibility goals.
3. Prepare R15 rig, body part segmentation, skin weights, attachments, cages/wraps where required, and facial/head requirements where applicable.
4. Import with `roblox-studio-importer` and validate with Avatar Setup/current Roblox tooling.
5. Test movement, scaling, accessories, layered clothing, emotes, and camera readability.
6. Route Marketplace checks to `roblox-ugc-marketplace` and external rig repair to `blender-rigify-roblox`.

## Body Checks

- Clean deformation at shoulders, elbows, wrists, hips, knees, ankles, neck, and waist.
- Attachments support standard accessories.
- Body scale does not break gameplay collision or camera framing.
- Textures are original, consistent, and not over-detailed for mobile.
- Head/face features meet the target avatar system requirements.

## Anti-Patterns

- Do not ship one good preview pose without testing animation extremes.
- Do not ignore clothing/accessory compatibility if the body is player-facing.
- Do not treat Marketplace validation as static; recheck current requirements before submission.

## Output Style

- State body type and target distribution first.
- Separate rigging, import, validation, compatibility, and submission concerns.
- Provide blockers as a checklist the artist can act on.
