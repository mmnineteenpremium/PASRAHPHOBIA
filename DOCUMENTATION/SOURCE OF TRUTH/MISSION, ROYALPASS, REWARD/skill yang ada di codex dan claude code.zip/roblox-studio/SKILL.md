---
name: roblox-studio
description: "Handle general Roblox Studio workflows: project setup, Explorer organization, Studio tools, asset import routing, UI assembly, terrain, animation setup, avatar tooling, testing, debugging, optimization, publishing, Team Create, and Indonesian requests about Roblox Studio that are not primarily engine API, networking, persistence, monetization, economy, ads, finance, or UGC submission."
---

# Roblox Studio

Use this skill for broad Studio execution and project organization. Route specialized domains to sibling skills so loaded context stays small.

## Asset Generation Routing

- For Roblox icons, billboards, UI, borders, HUD/static overlays, and visual references, route to Google Nano Banana via `generate_visual.py`.
- For new 3D model generation, create a reference image first, then prefer Roblox Studio MCP generation, then Cube3D local, then Tripo3D if available/requested, then Blender.
- For animation, prefer Roblox Studio tooling/Animation Editor first, then Blender when needed.

## Focus Boundary

- Use this skill for setup, Explorer structure, Studio workflow, UI placement, terrain, animation setup, debugging, optimization, test flow, and publish readiness.
- Use `roblox-studio-tools` when the user asks about all Studio tools or which tool to open.
- Use `roblox-studio-importer` for meshes, rigs, textures, audio, decals, packages, and Asset Manager/3D Importer details.
- Use `roblox-avatar-maker` and its narrow child skills for R15, bodies, accessories, clothing, makeup, emotes, and UGC workflows.
- Use `roblox-open-cloud` for Cloud API, API keys, CI/CD publishing, and automated uploads.
- Use `roblox-collaboration` for Team Create, groups, permissions, version history, and shared ownership.
- Use `roblox-asset-id-manager` for asset ID inventories, ownership checks, and ID migrations.
- Use `roblox-monetization`, `roblox-economy-design`, `roblox-creator-finances`, or `roblox-ads` for business systems.
- Use `roblox-engine-reference` for classes, services, properties, methods, events, enums, data types, or current engine behavior.
- Use `roblox-networking-security` for replication, remotes, StreamingEnabled, server authority, or anti-exploit boundaries.
- Use `roblox-data-persistence` for DataStoreService, MemoryStoreService, leaderboards, queues, or save pipelines.

## Workflow

1. Identify the target Studio task: structure, build, import, UI, terrain, avatar, animation, test, optimization, collaboration, or publish.
2. Inspect Explorer layout and map each script or asset to the correct service.
3. Read `references/project-patterns.md` for placement rules, import checks, and ship-readiness steps when project organization is involved.
4. Explain what changes, where it belongs in Studio, and why that location is correct.
5. Verify against official Roblox sources when the answer depends on current Studio features, plugin behavior, or recent platform changes.
6. Use `roblox-studio-multiplayer-test` for Test Server + 2 Clients, multi-window smoke tests, or screenshot-driven multiplayer validation.

## Working Rules

- Keep script ownership explicit: server, client, or shared.
- Prefer predictable hierarchy over hidden magic.
- Mention asset pipeline risks early: scale, pivot, collisions, textures, rigging, ownership, and triangle count.
- If a bug depends on hierarchy or object names, inspect the Explorer layout or relevant script path first.
- Treat publish readiness as part of the task whenever the user is close to shipping.

## Output Style

- Give steps in Studio order so the user can execute them directly.
- For code answers, label the intended script type and target service.
- For architecture questions, separate client, server, shared, assets, and dashboard work.
- Flag when a sibling Roblox skill is the better fit for the dominant subproblem.

