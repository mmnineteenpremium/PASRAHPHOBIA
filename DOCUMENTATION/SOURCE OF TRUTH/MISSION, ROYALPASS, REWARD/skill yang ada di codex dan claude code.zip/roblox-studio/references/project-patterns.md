# Roblox Studio Patterns

Use this reference when planning project structure, asset flow, or publish readiness.

## Sibling Skills

- Open `roblox-engine-reference` when the dominant question is about an exact API, class, service, property, method, event, enum, or data type.
- Open `roblox-networking-security` when replication, remotes, StreamingEnabled, network ownership, or exploit resistance dominates the task.
- Open `roblox-data-persistence` when save pipelines, leaderboards, queues, or session data dominate the task.
- Open `roblox-monetization` when the task is about products, purchases, or payout-aware implementation.
- Open `roblox-economy-design` when the task is about pricing, sinks and faucets, premium value, or monetization analytics.

## Runtime Placement

- Put authoritative gameplay logic in `ServerScriptService`.
- Put reusable shared modules in `ReplicatedStorage`.
- Put client-only UI and input logic in `StarterPlayerScripts` or `StarterGui`.
- Put tools in `StarterPack` and assets in appropriate containers.

## Network Rules

- Use `RemoteEvent` for async signals and `RemoteFunction` only when a response is actually required.
- Validate every client request on the server.
- Replicate only the data the client needs.
- Move deep replication or anti-exploit design to `roblox-networking-security`.

## Asset Import Checks

- Verify scale, pivot, orientation, collisions, materials, and texture compression.
- Check whether a mesh should use custom collision or simple collision.
- Keep triangle counts realistic for the target experience.

## Debugging Checklist

- Confirm the script type and service location.
- Confirm object names and hierarchy.
- Confirm the event actually fires on the expected side.
- Print or inspect values at client and server boundaries.

## Publish Checklist

- Test in Studio play mode and a realistic multiplayer session.
- Review permissions, monetization hooks, and game settings.
- Remove dead assets and debug remnants before publishing.
