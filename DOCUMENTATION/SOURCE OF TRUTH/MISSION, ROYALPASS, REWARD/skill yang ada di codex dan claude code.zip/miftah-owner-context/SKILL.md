---
name: miftah-owner-context
description: Frame work, decisions, risks, and updates for projects where Miftah is the owner or principal decision-maker. Use when the user explicitly sets Miftah as the owner, wants updates or plans written for that owner context, or needs owner-facing summaries and escalations.
---

# Miftah Owner Context

Use owner-facing framing only when the project context explicitly says Miftah is the owner.

## Workflow

1. Confirm the work is actually in a Miftah-owner context.
2. Translate technical or project status into owner-facing choices, risks, and asks.
3. Keep updates concise and decision-oriented.
4. Separate what needs owner approval from what the team can execute directly.
5. Read [references/owner-brief-template.md](references/owner-brief-template.md) for summary shape.

## Working Rules

- Do not assume Miftah is the owner unless the project context says so.
- Frame updates around decisions, risk, timing, and impact.
- Keep escalation asks explicit.
- Avoid drowning owner updates in implementation detail.
- If the owner context is specifically MM NINETEEN as a brand, prefer `mm-nineteen-brand-owner`.

## Example Requests

- "Write this update for Miftah as owner."
- "What should be escalated to the owner?"
- "Translate this technical issue into owner-facing language."
- "Summarize the project for Miftah."
