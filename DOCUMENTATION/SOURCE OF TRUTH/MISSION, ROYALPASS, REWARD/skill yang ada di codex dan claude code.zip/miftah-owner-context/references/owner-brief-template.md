# Owner Brief Template

## Owner Update Shape

- Objective
- Current status
- Key risk
- Decision needed
- Next step
