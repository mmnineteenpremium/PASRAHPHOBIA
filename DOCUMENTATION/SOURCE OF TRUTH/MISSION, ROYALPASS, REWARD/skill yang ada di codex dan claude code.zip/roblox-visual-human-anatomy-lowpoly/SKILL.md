---
name: roblox-visual-human-anatomy-lowpoly
description: Use for visual anatomy guidance that makes Roblox low-poly humans, creatures, NPCs, cosmetics, and stylized game characters read as realistic to human viewers while staying mobile-friendly and rig-ready.
---

# Roblox Visual Human Anatomy Lowpoly

Use this skill when designing or reviewing humanoid, creature, NPC, cosmetic, or body-like Roblox assets where low-poly style still needs realistic visual readability.

## Human Visual Readability

- Human viewers read realism first from silhouette, proportion, posture, material cues, and motion, not raw polygon count.
- Prioritize clear head/torso/limb masses, believable joint placement, and consistent left/right anatomy.
- Keep hands, feet, face planes, shoulders, hips, knees, and elbows readable even if simplified.
- Use value contrast and material grouping to separate skin, cloth, hair, armor, props, and supernatural effects.

## Roblox Low-Poly Realism

- Use larger simple forms with clean bevels instead of noisy high-poly detail.
- Put detail where players look: face, hands, chest emblem, held item, and silhouette edges.
- Make the model readable from mobile camera distance; tiny anatomy details should become texture or color blocks.
- Use Roblox-friendly segmentation for animation: head, torso, upper/lower arms, hands, upper/lower legs, feet, accessories, wings/tails/tools as named components.

## 3D Reference Workflow

1. Generate an orthographic reference first:
   `python D:\MovedFromC_UserProfile\.codex\tools\roblox-asset-workflow\generate_visual.py --prompt "<character or creature>" --type reference`
2. Analyze front/side anatomy, proportions, silhouette, and component boundaries.
3. For Studio MCP or Cube3D generation, request separated rig-ready components and clear joint pivots.
4. For Blender cleanup, retopologize around shoulders, elbows, hips, knees, neck, jaw, and accessory attachment points.

## Rigging and Animation Cues

- Place pivots where the viewer expects biological movement: shoulder socket, elbow hinge, wrist, hip socket, knee, ankle, neck base.
- For stylized horror characters, exaggerate one or two features only; keep the rest anatomically stable so motion remains believable.
- Never trade animation clarity for decorative mesh complexity.
