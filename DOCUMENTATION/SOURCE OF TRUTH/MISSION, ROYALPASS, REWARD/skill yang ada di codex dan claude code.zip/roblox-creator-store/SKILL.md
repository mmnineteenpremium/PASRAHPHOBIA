---
name: roblox-creator-store
description: "Use for Roblox Creator Store workflows: publishing models, plugins, audio, images, meshes, packages, asset metadata, thumbnails, permissions, free/paid asset strategy, discovery, Creator Store quality checks, dependency cleanup, and distinguishing Creator Store assets from avatar Marketplace UGC."
---

# Roblox Creator Store

Use this skill for Creator Store assets that other creators may find, install, reuse, or buy.

## Workflow

1. Identify asset type: model, plugin, package, audio, image, mesh, decal, video, or template.
2. Clean the asset before publishing: names, hierarchy, scripts, attributes, dependencies, permissions, thumbnails, and documentation inside the asset where useful.
3. Remove secrets, private IDs, debug scripts, hidden remotes, and project-specific assumptions.
4. Set ownership, creator/group, metadata, tags, license/usage notes, and pricing/distribution intent.
5. Test insertion from a separate place/account context when practical.
6. Track asset ID, version, owner, price, dependencies, and review status with `roblox-asset-id-manager`.

## Quality Checks

- Asset inserts cleanly without external missing dependencies.
- Scripts are safe, readable, and do not phone home unexpectedly.
- Plugin permissions and behavior are explicit.
- Thumbnail and title match the actual asset.
- Public assets do not include private game logic, keys, account data, or unreleased IP.

## Routing

- Avatar item sale or UGC: `roblox-ugc-marketplace`.
- Monetized in-experience products: `roblox-monetization`.
- Revenue/payout analysis: `roblox-creator-finances`.
- Ads or promotion: `roblox-ads`.

## Output Style

- State whether the asset belongs in Creator Store or avatar Marketplace.
- Provide pre-publish cleanup, metadata, permission, and post-publish verification steps.
- Call out security and ownership blockers before distribution.

