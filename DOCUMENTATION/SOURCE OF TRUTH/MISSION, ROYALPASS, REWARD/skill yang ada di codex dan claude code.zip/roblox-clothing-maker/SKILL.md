---
name: roblox-clothing-maker
description: Use for Roblox clothing creation, classic shirts/pants/T-shirts, layered clothing, cages, wraps, attachments, body compatibility, texture templates, clothing import, avatar preview, Creator Dashboard upload, Marketplace readiness, and troubleshooting clothing deformation or fit.
---

# Roblox Clothing Maker

Use this skill for classic clothing and layered clothing production.

## Workflow

1. Determine clothing type: classic shirt, classic pants, T-shirt, layered jacket, shirt, pants, shorts, dress, skirt, shoe, or in-experience-only cosmetic.
2. For classic clothing, prepare template artwork, transparency, seams, and preview on multiple body scales.
3. For layered clothing, validate mesh topology, cage/wrap setup, deformation, thickness, and body compatibility.
4. Import or upload using the appropriate Studio or Creator Dashboard path.
5. Test with common R15 body sizes, accessories, animations, and camera distances.
6. Route public sale or UGC submission to `roblox-ugc-marketplace`.

## Quality Checks

- Seams align and do not expose unwanted gaps.
- Textures are readable on mobile and avoid muddy fine detail.
- Layered clothing deforms without clipping badly during standard animations.
- Item scale and pivot are appropriate for avatar preview.
- Source art is original or properly licensed.

## Debugging

- Texture appears shifted: revisit template layout and UVs.
- Clipping on movement: adjust cage/wrap, thickness, or fit target.
- Upload rejected: verify current category, metadata, and moderation rules.
- Looks good in editor but not in-game: test on real avatar scales and animation states.

## Output Style

- State classic versus layered clothing first.
- Provide separate art, mesh, Studio import, and validation steps.
- Flag Marketplace compliance separately from technical fit issues.
