---
name: roblox-player-facing-systems
description: Use for Roblox player-facing systems such as onboarding, tutorials, quests, inventory, equipment, cosmetics, avatar customization UI, shops, progression, achievements, daily rewards, settings, feedback, notifications, accessibility, localization-ready UX, and mobile-first in-game flows that combine UI, server validation, persistence, and economy design.
---

# Roblox Player Facing Systems

Use this skill when the player experience spans UI, gameplay state, persistence, rewards, inventory, or customization. Keep systems server-authoritative and easy to test on mobile.

## Workflow

1. Define the player promise: what the player sees, chooses, earns, equips, unlocks, or changes.
2. Split the system into UI, client prediction, server authority, persistence, economy/rewards, analytics, and live-ops knobs.
3. Route subproblems to sibling skills: UI to `roblox-ui-design`, remotes to `roblox-networking-security`, saves to `roblox-data-persistence`, rewards/pricing to `roblox-economy-design`, purchases to `roblox-monetization`, and avatar cosmetics to `roblox-avatar-maker`.
4. Design failure states: loading, no data, save failure, ownership missing, inventory full, cooldown active, and offline/teleport edge cases.
5. Verify with at least one mobile layout check and one server-authority abuse case.

## System Patterns

- Inventory: server owns item grants, removes, equips, stacking, and ownership checks.
- Quests: server owns progress increments and completion rewards; client only displays state.
- Shops: server verifies price, ownership, stock, cooldown, and receipt state.
- Cosmetics: server validates owned asset/product before applying appearance changes.
- Daily rewards: server owns time source, streaks, and missed-day logic.
- Settings: client may store local-only preferences; server stores preferences that affect gameplay or cross-device state.
- Tutorials: track completion state, but allow safe replays and skip logic when appropriate.

## UX Rules

- Design for mobile first: large tap targets, readable text, safe areas, and short flows.
- Avoid blocking gameplay with long modal chains.
- Make rewards and costs clear before the player commits.
- Provide recoverable states when data, ownership, or network checks fail.
- Keep analytics events tied to meaningful steps, not every small UI movement.

## Output Style

- Start with the player journey.
- Then give client, server, persistence, UI, and analytics responsibilities.
- Include abuse cases and smoke tests for the finished flow.
