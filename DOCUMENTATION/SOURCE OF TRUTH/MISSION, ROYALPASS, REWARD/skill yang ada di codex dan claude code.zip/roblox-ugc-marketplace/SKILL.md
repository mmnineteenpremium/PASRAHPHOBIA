---
name: roblox-ugc-marketplace
description: Use for Roblox UGC and Marketplace publishing workflows, avatar item readiness, moderation-sensitive checks, upload categories, item metadata, sales setup, Marketplace compliance, creator permissions, and routing body, clothing, accessory, makeup, or emote assets to the correct Roblox validation path.
---

# Roblox UGC Marketplace

Use this skill when an avatar item or creator asset is intended for public Roblox distribution or sale.

## Workflow

1. Identify item class: accessory, clothing, body, head, face/makeup, emote, model, plugin, audio, image, or other Creator Store asset.
2. Route production to the relevant maker skill before submission.
3. Verify current Roblox Marketplace, Creator Store, moderation, and eligibility requirements from official docs and Creator Dashboard.
4. Check source ownership, originality, trademark risk, naming, thumbnails, and metadata.
5. Validate technical requirements with Studio tooling before upload.
6. Track uploaded asset IDs, versioning, owner/group, price, sales status, and dependencies.

## Submission Checks

- Correct category and asset type.
- Clean geometry, textures, scale, pivots, attachments, and rigging.
- No copyrighted logos, protected character likenesses, or unlicensed source material.
- Metadata is clear and not misleading.
- Thumbnail accurately represents the item.
- Creator account/group permissions and payout readiness are confirmed.

## Routing

- Accessories: `roblox-accessories-maker`.
- Bodies and heads: `roblox-bodies-maker` and `roblox-avatar-r15-maker`.
- Clothing: `roblox-clothing-maker`.
- Makeup or face textures: `roblox-makeup-maker`.
- Emotes: `roblox-animation-emotes`.
- Store analytics, sales, and payouts: `roblox-creator-finances`.

## Output Style

- Start with a submission readiness verdict: ready, needs fixes, or blocked.
- Separate technical validation, policy/compliance risk, metadata, and sales setup.
- Avoid claiming guaranteed approval; Roblox moderation and eligibility can change.
