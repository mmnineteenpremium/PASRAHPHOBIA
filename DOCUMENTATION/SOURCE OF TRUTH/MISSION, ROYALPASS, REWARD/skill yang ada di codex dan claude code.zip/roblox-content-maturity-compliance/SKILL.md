---
name: roblox-content-maturity-compliance
description: Use for Roblox Content Maturity, Maturity & Compliance Questionnaire, Restricted/17+ access, age/region playability gates, PolicyService audience handling, and Indonesian requests about fixing a Roblox experience that is public but cannot be joined because of content rating, age rating, or compliance settings.
---

# Roblox Content Maturity Compliance

Use this skill when a Roblox experience is public/published but players cannot join, listing APIs return empty, or Creator Dashboard shows `Content ratings`, `Maturity & Compliance`, `Questionnaire`, `Restricted`, `17+`, `Terbatas`, age, or regional access gates.

## Operating Rules

- Use official Roblox documentation first for policy, maturity labels, and Open Cloud endpoint behavior.
- Do not falsify or under-report questionnaire answers. Answers must reflect the most mature or extreme content players can encounter.
- Prefer fixing content or configuration over bypassing policy.
- Treat questionnaire submission as a creator compliance action. If automating it, record the evidence used for each answer and keep the owner-facing report clear.
- Open Cloud API keys can manage supported universe/place settings, but content maturity labels and age ratings are read-only in the public Open Cloud `Universe` resource unless Roblox documents a write endpoint.
- For Restricted/Terbatas experiences, verify the test account is eligible for that rating before treating join failure as a code/server crash.

## Workflow

1. Confirm target `universeId`, `placeId`, owner, branch, and publish timestamp.
2. Reproduce the player-facing failure with screenshot and Player logs.
3. Query official metadata:
   - `GET /cloud/v2/universes/{universe_id}`
   - `GET /cloud/v2/universes/{universe_id}/places/{place_id}`
   - public game details and public server list endpoints for correlation.
4. Inspect Creator Dashboard `Audience > Maturity & Compliance` / `Questionnaire` for label, descriptors, and non-compliant regions.
5. Audit the game content that maps to descriptors: violence, blood, fear, crude humor, strong language, gambling, alcohol, romantic themes, social hangout/private spaces, media sharing, AI/generative features, paid item trading.
6. Decide the compliant fix:
   - If label is accurate: use eligible account/device/region or implement age-aware content paths with `PolicyService`.
   - If label overstates current content: retake questionnaire accurately.
   - If desired audience is broader: remove or gate content that creates the higher label, publish, then retake questionnaire accurately.
7. Retest live join through Roblox Player and record screenshot/log evidence.

## Stop Conditions

- Stop only for policy uncertainty that cannot be resolved from official docs or current game content.
- Do not stop just because the fix is in Creator Dashboard instead of code; drive the dashboard/API path when credentials and permission are available.
