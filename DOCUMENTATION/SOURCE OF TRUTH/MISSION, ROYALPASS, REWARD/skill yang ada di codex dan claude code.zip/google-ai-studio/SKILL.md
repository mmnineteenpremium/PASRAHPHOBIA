---
name: google-ai-studio
description: Use for Google AI Studio setup, Gemini API key guidance, google-genai authentication, model selection for Gemini/Nano Banana image generation, and troubleshooting Google AI Studio access for local asset tools.
---

# Google AI Studio

Use this skill when the user needs Google AI Studio, Gemini API, or `google-genai` setup for local tools.

## Workflow

1. Use official Google AI Studio/API docs for current model names and SDK behavior.
2. Check credentials before generation:
   - `GEMINI_API_KEY`
   - `GOOGLE_API_KEY`
   - `GOOGLE_APPLICATION_CREDENTIALS`
3. For local image generation, prefer the project tool:
   `python D:\MovedFromC_UserProfile\.codex\tools\roblox-asset-workflow\generate_visual.py --prompt "<prompt>" --type <icon|billboard|ui|reference>`
4. If credentials are missing, tell the user to create an API key in Google AI Studio and set it in the current shell or user environment.

## Model Defaults

- Professional image production: `gemini-3-pro-image-preview`
- High-volume faster image production: `gemini-3.1-flash-image-preview`
- Legacy fast Nano Banana: `gemini-2.5-flash-image`

## Rules

- Never print full API keys.
- Do not claim generation is ready until credentials are present and `python ...generate_visual.py --help` passes.
- Note that Gemini generated images include SynthID; local crop steps only reduce visible edge/corner artifact risk.
