---
name: roblox-makeup-maker
description: Use for Roblox makeup, face cosmetics, face textures, skin overlays, head/face art, avatar cosmetic surface design, texture alignment, moderation-sensitive cosmetic metadata, and preparing makeup-style avatar assets for in-game use or Marketplace/UGC submission.
---

# Roblox Makeup Maker

Use this skill for face and cosmetic texture workflows on Roblox avatars.

## Workflow

1. Define whether the makeup is an in-experience cosmetic, a face texture, a head/body texture detail, or part of a Marketplace avatar item.
2. Identify the target head/body topology and UV layout before painting.
3. Produce clean texture layers for base color, brows, eye detail, lips, contour, blush, markings, or stylized effects.
4. Test alignment on neutral expression, animation poses, and multiple lighting conditions.
5. Validate policy sensitivity around realistic identity, copyrighted characters, brands, offensive markings, and misleading thumbnails.
6. Route body/head submission to `roblox-bodies-maker` or UGC publishing to `roblox-ugc-marketplace`.

## Quality Checks

- Makeup aligns to the intended head UVs and facial landmarks.
- Contrast remains readable at avatar scale without becoming noisy.
- Colors work across the intended skin tone range or are clearly tied to a specific body texture.
- Textures avoid baked lighting that conflicts with Roblox scene lighting.
- Metadata describes the cosmetic honestly.

## Output Style

- State the target delivery: texture-only, body/head package, accessory-like cosmetic, or in-game UI option.
- Separate texture art, Studio preview, and Marketplace/compliance steps.
- Flag when current Roblox docs or Creator Dashboard requirements must be checked before upload.
