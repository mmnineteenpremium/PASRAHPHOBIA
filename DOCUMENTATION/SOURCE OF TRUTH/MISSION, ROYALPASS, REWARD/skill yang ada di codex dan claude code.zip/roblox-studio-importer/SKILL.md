---
name: roblox-studio-importer
description: "Use for Roblox Studio import workflows: 3D Importer, Asset Manager imports, mesh/FBX/glTF/OBJ files, textures, PBR SurfaceAppearance, animations, rigs, audio, decals, packages, scale/pivot/collision setup, import troubleshooting, and preparing assets from Blender, Meshy, Hunyuan3D, or other DCC tools for Roblox."
---

# Roblox Studio Importer

Use this skill when an external asset needs to become a clean Roblox Studio asset.

## Generation Routing Before Import

- If the asset is not created yet, generate a Google Nano Banana reference first with `generate_visual.py --type reference`.
- Preferred 3D creation order is Roblox Studio MCP, then Cube3D local, then Tripo3D if available/requested, then Blender cleanup/authoring.
- When using generated 3D output, require named separable components and rig-ready joints/attachments before import whenever the asset must animate.
- If Studio MCP is offline or the user requests raw files, use local Cube3D and then import/clean the resulting `.obj`/`.fbx`.

## Workflow

1. Identify asset type: static mesh, skinned mesh, R15 body, accessory, clothing, animation, audio, decal, image, package, or model.
2. Validate the source file before Studio import: format, units, pivot, origin, hierarchy, names, texture paths, bones, and animations.
3. Use the right Studio path: 3D Importer for mesh and rig files, Asset Manager for uploaded assets, Animation Editor for animation work, and Avatar Setup or Accessory Fitting Tool for avatar items.
4. After import, inspect scale, collisions, pivots, materials, SurfaceAppearance, texture memory, triangle count, and mobile readability.
5. Save IDs and ownership in an asset map with `roblox-asset-id-manager`.
6. Re-test in Play mode, not only edit mode.

## Import Rules

- Prefer simple hierarchy and stable names over deeply nested export clutter.
- Keep collision geometry deliberate; do not rely on high-poly visual meshes for gameplay collision.
- Keep material slots and texture sets predictable before upload.
- For skinned meshes, check bind pose, bone names, deformation, and Roblox avatar requirements.
- For generated AI meshes, clean scale, topology, normals, and texture resolution before import.

## Troubleshooting

- Wrong scale: verify DCC export units and Studio import scale.
- Missing textures: check embedded media, relative paths, and material assignments.
- Broken rig: inspect armature hierarchy, bind pose, weights, and Roblox avatar requirements.
- Bad collisions: generate or author simpler collision parts.
- Asset not visible to teammates: check owner, group, privacy, and Creator Dashboard permissions.

## Output Style

- Give a source-tool checklist and a Studio-side checklist.
- State the correct target service/folder in Explorer.
- Mark issues that must be fixed before upload versus issues that can be fixed after import.

