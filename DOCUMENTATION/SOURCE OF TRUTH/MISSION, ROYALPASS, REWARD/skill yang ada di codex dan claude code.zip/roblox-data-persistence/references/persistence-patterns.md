# Roblox Persistence Patterns

Use this file when the task involves player data, leaderboards, queues, or cross-server coordination.

## Official Entry Points

- Data stores: `https://create.roblox.com/docs/cloud-services/data-stores`
- Memory stores: `https://create.roblox.com/docs/cloud-services/memory-stores`
- Engine reference root: `https://create.roblox.com/docs/id-id/reference/engine`

## Storage Selection

- `DataStoreService`: durable player or game data
- `OrderedDataStore`: sorted numeric ranking data
- `MemoryStoreService`: ephemeral queues, locks, rate-limit buckets, short-lived coordination

## Durable Save Rules

- Load once when the server session starts using the player data.
- Keep a server-side session model and mutate that model instead of writing on every tiny change.
- Save at meaningful checkpoints and on shutdown paths such as `PlayerRemoving` or `BindToClose`.
- Version the stored schema so migrations are explicit.
- Serialize plain data, not live Instances.

## Safety Rules

- Use `UpdateAsync` when multiple servers or retries may touch the same key.
- Make grants and save steps idempotent when duplicate calls are possible.
- Validate payload size and shape before writing.
- Decide what happens when loading fails before the player enters the full game loop.
- Queue retries with bounded backoff instead of infinite tight loops.

## Debugging Checklist

- Is the code running on the server?
- Is the key stable and correctly namespaced?
- Is the schema consistent across load and save?
- Is the write path retry-safe?
- Is transient coordination mistakenly being stored in a durable data store?
