---
name: roblox-data-persistence
description: Design and debug Roblox persistence with DataStoreService, OrderedDataStore, MemoryStoreService, schema evolution, retries, save pipelines, and session-safe state ownership. Use when Codex needs help with player saves, leaderboards, queues, cross-server coordination, or Indonesian requests about Roblox data persistence.
---

# Roblox Data Persistence

Use this skill when the critical problem is durable or ephemeral state. Keep write safety, idempotency, and schema clarity ahead of convenience.

## Workflow

1. Identify the state type: durable save, sorted leaderboard, ephemeral queue, lock, or cross-server signal.
2. Open [references/persistence-patterns.md](references/persistence-patterns.md) for storage selection and save-safety rules.
3. Define the schema, ownership rules, and serialization boundaries before writing API calls.
4. Design the load, cache, mutate, save, retry, and shutdown flow.
5. If monetized entitlements are involved, also consult `roblox-monetization` so purchase fulfillment and persistence line up.

## Working Rules

- Keep persistence authoritative on the server.
- Load once per session, cache in memory, and write from explicit checkpoints.
- Prefer versioned schemas and migration-aware serializers.
- Use `UpdateAsync` for contested or merge-heavy keys.
- Use `OrderedDataStore` only for sorted numeric ranking cases.
- Use `MemoryStoreService` for ephemeral coordination, not permanent saves.
- Make save paths idempotent whenever retries or duplicate events are possible.

## Reference Files

- Read [references/persistence-patterns.md](references/persistence-patterns.md) for storage selection, write safety, and debugging checks.

## Output Style

- State the storage primitive being used and why.
- Separate session cache, durable store, and transient coordination paths.
- Call out failure handling, retries, and shutdown behavior.

## Example Requests

- "How should I save player inventory safely in Roblox?"
- "Should this leaderboard use `OrderedDataStore` or something else?"
- "How do I prevent duplicate grants when a save retries?"
- "What should go in `MemoryStoreService` versus `DataStoreService`?"
