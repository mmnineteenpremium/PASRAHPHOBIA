---
name: roblox-studio-tools
description: "Use as a routing guide for all Roblox Studio built-in tools and Creator workflows: Explorer, Properties, Asset Manager, Toolbox/Creator Store, 3D Importer, Material Manager, Terrain Editor, Animation Editor, Avatar Setup, Accessory Fitting Tool, UI Editor, Game Settings, Team Create, Version History, Profiler, MicroProfiler, Script Performance, Memory, Output, Tags, Packages, Localization, Publishing, and cloud-connected Studio workflows."
---

# Roblox Studio Tools

Use this skill when the user asks which Roblox Studio tool to use or wants complete coverage of Studio tooling.

## Tool Routing

- Explorer and Properties: hierarchy, services, object placement, attributes, tags, and property debugging.
- Asset Manager: uploaded assets, images, meshes, audio, packages, places, and asset insertion.
- Toolbox and Creator Store: discover reusable assets, models, plugins, audio, images, and packages.
- 3D Importer: meshes, FBX/glTF/OBJ, skinned rigs, textures, and import options. Use `roblox-studio-importer`.
- Material Manager and MaterialService: material variants, PBR surfaces, and scene material consistency.
- Terrain Editor: terrain sculpting, painting, water, caves, and large-world readability.
- Animation Editor: R15/R6/custom rig animations and emotes. Use `roblox-animation-emotes`.
- Avatar Setup and Accessory Fitting Tool: bodies, heads, accessories, clothing, and avatar validation.
- UI tools: ScreenGui, constraints, safe areas, text scaling, and mobile ergonomics. Use `roblox-ui-design`.
- Game Settings: permissions, monetization, security, avatar, localization, and publishing configuration.
- Team Create, Version History, and Packages: collaboration, rollback, shared assets, and release control. Use `roblox-collaboration`.
- Output, Log, Script Analysis, Script Performance, Memory, Profiler, and MicroProfiler: debugging and performance diagnosis.
- Tag Editor and CollectionService workflows: object grouping and runtime discovery.
- Localization tools: source strings, translations, and locale testing.
- Publishing/Open Cloud: publish flow, universe/place IDs, and CI/CD. Use `roblox-open-cloud`.

## Workflow

1. Classify the task as build, art import, avatar, script, UI, animation, test, performance, collaboration, publish, monetization, finance, or promotion.
2. Pick the narrowest tool and skill for that task.
3. Inspect the Explorer and asset ownership context before changing data.
4. Prefer official Roblox docs for current Studio UI labels and feature availability.
5. Produce steps in the same order the user should perform them in Studio.

## Output Style

- Start with the exact Studio tool to open.
- Include the target service/folder or Creator Dashboard page when relevant.
- Route specialized implementation to the matching `roblox-*` skill instead of overloading this guide.

