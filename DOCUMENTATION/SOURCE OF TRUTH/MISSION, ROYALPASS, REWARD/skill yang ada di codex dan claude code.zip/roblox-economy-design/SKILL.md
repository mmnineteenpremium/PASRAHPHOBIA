---
name: roblox-economy-design
description: Plan Roblox economy design, pricing ladders, reward pacing, currency faucets and sinks, premium value, live ops, experiments, and monetization analytics. Use when Codex needs to balance progression, review conversion funnels, connect economy health to retention and revenue metrics, or answer Indonesian requests about Roblox economy design.
---

# Roblox Economy Design

Use this skill when the question is not just "how do I wire the purchase," but "what should players earn, buy, save, and value over time."

## Workflow

1. Identify the target loop: early progression, long-term retention, store mix, event economy, or pricing.
2. Open [references/economy-playbook.md](references/economy-playbook.md) for Roblox-specific economy and analytics guidance.
3. Map the economy into faucets, sinks, gates, premium value, and restore requirements.
4. Tie design choices to measurable metrics such as payer conversion, ARPPU, ARPDAU, session time, or retention.
5. If the task becomes implementation-heavy, also consult `roblox-monetization` or `roblox-data-persistence`.

## Working Rules

- Keep the free loop fun before optimizing spend.
- Use premium purchases to accelerate, expand, personalize, or reduce friction without collapsing fairness.
- Design multiple price points for different engagement levels.
- Match sinks and faucets so inflation or dead-end scarcity does not dominate the loop.
- Use experiments and analytics to validate pricing or offer changes instead of guessing.
- Treat live ops as a structured extension of the core economy, not a replacement for it.

## Reference Files

- Read [references/economy-playbook.md](references/economy-playbook.md) for loop design, analytics targets, and official Roblox doc roots.

## Output Style

- State the target player segment and loop first.
- Separate faucets, sinks, gates, and premium offers.
- Tie each recommendation to a Roblox metric or business outcome.

## Example Requests

- "How should I structure a Roblox soft-currency economy for a tycoon?"
- "What price ladder should this shop use for new and repeat buyers?"
- "Why is ARPPU high but ARPDAU low in this experience?"
- "How should I plan a seasonal event economy without breaking progression?"
