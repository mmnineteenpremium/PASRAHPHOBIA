# Roblox Economy Playbook

Use this file when the task is about economy structure, pricing, or monetization analytics.

## Official Entry Points

- Analytics overview: `https://create.roblox.com/docs/production/analytics`
- Monetization analytics: `https://create.roblox.com/docs/production/analytics/monetization`
- Monetization overview: `https://create.roblox.com/docs/production/monetization`
- Experiments: `https://create.roblox.com/docs/production/experiments`
- Analytics essentials: `https://create.roblox.com/docs/production/game-design/analytics-essentials`

## Core Economy Lens

- Faucets: how players earn currency or resources
- Sinks: how players spend them
- Gates: what progression milestones or scarcity controls access
- Premium offers: what paid products accelerate, unlock, or personalize
- Restore rules: which benefits persist across sessions and how they reappear

## Roblox-Specific Design Rules

- Support both short-term and long-term players with a mix of durable and repeatable offers.
- Keep multiple price points so low-spend and high-spend users both have sensible options.
- Use seasonal or themed offers to create novelty without invalidating the base economy.
- Avoid storefront friction and make item value legible inside the experience.
- Keep retention and engagement healthy before aggressively scaling user acquisition.

## Metric Mapping

- Low conversion: improve shop visibility, offer clarity, lower-cost entry products
- High ARPPU but low ARPDAU: widen the offer mix and price ladder
- Low retention: fix the core loop before adding more monetization pressure
- Flat revenue after updates: inspect content cadence, event design, and purchase discovery

## Experiment Checklist

- Change one major lever at a time: price, placement, bundle mix, or event reward
- Define the target metric before the experiment starts
- Check retention and sentiment alongside revenue metrics
- Keep a rollback path if the new economy hurts the core loop
