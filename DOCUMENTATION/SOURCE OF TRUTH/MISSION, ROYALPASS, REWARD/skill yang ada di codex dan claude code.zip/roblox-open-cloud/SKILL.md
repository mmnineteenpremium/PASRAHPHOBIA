---
name: roblox-open-cloud
description: Use for Roblox Open Cloud, Cloud API, API keys, universe/place publishing, asset or experience automation, CI deploys, creator dashboard API setup, and secure machine-to-Roblox workflows. Trigger for Indonesian or English requests mentioning Roblox Cloud API, Open Cloud, API key, universe ID, place ID, publish automation, CI/CD, asset upload automation, or Rojo Open Cloud publishing.
---

# Roblox Open Cloud

Use this skill when Roblox work leaves Studio and needs authenticated API access, automation, publishing, or CI/CD.

## Workflow

1. Identify the target resource: universe, place, experience, datastore, messaging, asset, group, or analytics endpoint.
2. Confirm required identifiers: universe ID, place ID, asset ID, group ID, creator user ID, and target environment.
3. Use official docs first: `https://create.roblox.com/docs/cloud` and the endpoint-specific Open Cloud reference.
4. Choose the least-privilege API key scope that can perform the requested action.
5. Keep secrets outside the repo: prefer `ROBLOX_OPEN_CLOUD_API_KEY`, CI secret storage, or machine/user environment variables.
6. Add dry-run validation before write operations when possible.
7. Log request target and response status, but never log API keys or bearer tokens.

## Safety Rules

- Do not paste API keys into source files, `.rbxlx`, `.project.json`, logs, or screenshots.
- Do not reuse a broad all-access key for local development and production CI.
- Treat place publishing, asset upload, and datastore writes as production-affecting operations.
- Verify current endpoint paths, scopes, and payload schemas against official Roblox docs before coding.
- When Rojo publish conflicts with Studio locks, close Studio and retry with backoff instead of changing project IDs blindly.

## Common Tasks

- Configure Rojo or custom scripts for Open Cloud publishing.
- Generate CI steps for uploading a place file to a universe/place.
- Debug `401`, `403`, missing scope, wrong universe/place ID, or rate-limit failures.
- Design asset upload or metadata automation without exposing credentials.
- Map Creator Dashboard IDs to local config files.

## Output Style

- State the exact target resource and required identifiers first.
- Separate local config, secret storage, API request, and verification steps.
- Include rollback or safety steps for production-affecting actions.
- If docs may have changed, explicitly say to recheck the official endpoint page before running write operations.
