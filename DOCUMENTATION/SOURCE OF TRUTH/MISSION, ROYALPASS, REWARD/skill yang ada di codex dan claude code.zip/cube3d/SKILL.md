---
name: cube3d
description: Use for local Roblox Cube/Cube3D text-to-3D generation, offline raw mesh export, checkpoint setup, OBJ/FBX conversion, and fallback 3D asset creation when Roblox Studio MCP is offline or the user requests raw 3D files.
---

# Cube3D

Use this skill when a Roblox 3D asset should be generated locally with Roblox Cube, especially when Studio MCP is unavailable or the user wants raw `.obj`/`.fbx` output.

## Default Order

1. Prefer Roblox Studio MCP generation when Studio is connected and the user wants the asset inside Workspace.
2. Use local Cube3D when Studio MCP is offline or raw files are requested.
3. Use Tripo3D only when available and requested or when Cube cannot satisfy the asset need.
4. Use Blender for cleanup, rigging, retopology, FBX export, or manual authoring fallback.

## Local Paths

- Cube repo: `D:\MovedFromC_UserProfile\.codex\tools\cube`
- PASRAHPHOBIA default output: `C:\Projects\ROBLOX\PASRAHPHOBIA\asset mentah\ROBLOX CREATOR HUB\[SECOND ACCOUNT]\`

## Workflow

1. Generate a visual reference first with Google Nano Banana:
   `python D:\MovedFromC_UserProfile\.codex\tools\roblox-asset-workflow\generate_visual.py --prompt "<prompt>" --type reference`
2. Confirm Cube has model weights in `D:\MovedFromC_UserProfile\.codex\tools\cube\model_weights`.
3. Run Cube through the global wrapper:
   `python D:\MovedFromC_UserProfile\.codex\tools\roblox-asset-workflow\generate_cube3d.py --prompt "<prompt>"`
   From PASRAHPHOBIA, use:
   `python scripts\generate_cube3d.py --prompt "<prompt>"`
4. If the asset must fit Roblox animation, request separable body/mechanical components in the prompt and clean the mesh into named pieces before import.
5. Convert or clean `.obj` to `.fbx` with Blender/Python only when needed for Studio import, rigging, or animation.

## Rules

- Do not call Cube a replacement for Studio rigging; Cube creates raw geometry.
- Do not skip checkpoint verification. The wrapper checks `model_weights/shape_gpt.safetensors` and `model_weights/shape_tokenizer.safetensors`; if they are missing, download the official Roblox Cube weights first.
- Keep outputs low-poly, mobile-readable, and named for Roblox import.
- Store final raw files and related generated references together in the project asset output folder.
