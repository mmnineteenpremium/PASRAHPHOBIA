---
name: google-nano-banana
description: Use for Google Nano Banana image generation workflows, Roblox icons, billboards, UI/HUD/static overlays, border assets, reference sheets, visual prompt shaping, and overscan-crop output with local generate_visual.py.
---

# Google Nano Banana

Use this skill for generated raster assets, especially Roblox icons, billboards, UI elements, borders, static overlays, HUD assets, and orthographic reference images for 3D work.

## Required Tool

Use the local workflow tool:

```powershell
python D:\MovedFromC_UserProfile\.codex\tools\roblox-asset-workflow\generate_visual.py --prompt "<prompt>" --type <icon|billboard|ui|reference>
```

For a project-local PASRAHPHOBIA call:

```powershell
python scripts\generate_visual.py --prompt "<prompt>" --type <icon|billboard|ui|reference>
```

## Asset Types

- `icon`: Roblox UI/icon asset, square, final `512x512`.
- `billboard`: cinematic landscape ad/signage, final `1024x576`.
- `ui`: clean-edged GUI/HUD/static overlay/border asset, final `1024x1024`.
- `reference`: orthographic front/side reference sheet for 3D modeling, final `1536x1024`.

## Prompt Rules

- Preserve the user's core prompt and add only production constraints needed for the asset type.
- Ask for safe overscan padding and keep important details in the central safe area.
- Avoid visible watermark-like marks, signatures, corner badges, sparkles/stars in margins, random text, and third-party logos.
- For 3D model requests, generate `--type reference` before choosing Studio MCP, Cube3D, Tripo3D, or Blender.

## Output Rules

- Default PASRAHPHOBIA output is:
  `C:\Projects\ROBLOX\PASRAHPHOBIA\asset mentah\ROBLOX CREATOR HUB\[SECOND ACCOUNT]\`
- Use `--out-dir` for other Roblox projects.
- Keep the generated `.json` metadata with the `.png`.
- Gemini images include SynthID; do not describe overscan crop as removing embedded provenance metadata.
