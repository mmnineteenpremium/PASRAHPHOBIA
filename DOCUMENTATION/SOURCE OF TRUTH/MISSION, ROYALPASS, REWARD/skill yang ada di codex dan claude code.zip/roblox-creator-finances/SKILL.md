---
name: roblox-creator-finances
description: Use for Roblox creator finances, revenue analysis, sales reports, payouts, DevEx readiness, transaction review, premium payouts, creator rewards, paid asset revenue, ad spend versus return, group fund governance, finance dashboards, and Indonesian requests about Roblox income, uang, payout, Robux, pajak, or laporan keuangan creator.
---

# Roblox Creator Finances

Use this skill for financial tracking and decision support around Roblox creator revenue and spend.

## Workflow

1. Identify finance surface: experience revenue, passes, developer products, subscriptions, paid access, private servers, Creator Store sales, avatar item sales, premium payouts, ad spend, or group funds.
2. Separate gross Robux, fees/commissions, refunds/chargebacks if visible, pending balances, spend, net Robux, and cash payout assumptions.
3. Pull current figures from Creator Dashboard, group funds, ad dashboards, and any project analytics exports the user provides.
4. Reconcile asset/product IDs with `roblox-asset-id-manager` and monetization design with `roblox-monetization`.
5. Evaluate campaign return with `roblox-ads` when ad spend is involved.
6. For tax, legal, or payout compliance, provide non-legal guidance and direct the user to official Roblox/accountant resources.

## Finance Checks

- Owner/group receiving funds is correct.
- Product/pass IDs match the shipped experience.
- Revenue is segmented by source and date range.
- Ad spend and creator payouts are not mixed with gross sales.
- Access to finance dashboards is least-privilege and controlled.

## Metrics

- Gross Robux and net Robux by source.
- ARPDAU, ARPPU, payer conversion, repeat purchase rate, and retention linkage.
- Ad spend, CPA/CPI proxy, ROAS, and payback period where data supports it.
- Creator Store asset sales and conversion by item.

## Output Style

- State the date range and source of truth first.
- Use tables for revenue/spend breakdowns.
- Mark unverifiable numbers as assumptions, not facts.
- Do not promise DevEx eligibility or payout timing without checking current official requirements.
