---
name: roblox-autonomous-orchestrator
description: "Autonomous orchestrator for Roblox projects: routes tasks to the right Roblox skills and enforces server-authoritative, policy-aware, Studio-aware decisions across coding, Cloud API, assets, avatar/UGC, monetization, ads, finance, collaboration, testing, and publishing."
---

# Roblox Autonomous Orchestrator

Use this skill to coordinate multi-step Roblox work across Studio, Luau code, art, avatar creation, cloud publishing, data, monetization, ads, finance, collaboration, and test validation.

## Operating Rules

- Assume the Roblox server is authoritative. Treat the client as untrusted.
- When proposing Luau APIs or Studio behavior, prefer `roblox-engine-reference` and official Roblox docs.
- Prefer incremental changes with a small smoke test plan.
- Keep API keys, cookies, finance access, and ad spend out of source files and chat transcripts.
- When a repo already has a project-local publish wrapper such as `scripts/rojo.ps1`, prefer that over ad-hoc commands.
- Use `ROBLOX_OPEN_CLOUD_API_KEY` or CI secret storage for Open Cloud automation.
- Do not keep Roblox Studio open during publish if publish conflicts are occurring. Close Studio first, then retry with backoff.

## Routing Map

- Studio tools and broad Studio workflow: `roblox-studio` and `roblox-studio-tools`.
- Engine API lookup and correctness: `roblox-engine-reference`.
- Remotes, replication, anti-exploit boundaries: `roblox-networking-security` and `roblox-multiplayer`.
- Saving, schema evolution, retries: `roblox-data-persistence`.
- Monetization products, receipts, restore entitlements: `roblox-monetization`.
- Economy balancing and pricing ladders: `roblox-economy-design`.
- Ads, campaign planning, ROAS: `roblox-ads`.
- Creator finances, payouts, revenue reports: `roblox-creator-finances`.
- Open Cloud, API keys, CI publish automation: `roblox-open-cloud`.
- Asset IDs, ownership, migration maps: `roblox-asset-id-manager`.
- Importing meshes, rigs, textures, audio, packages: `roblox-studio-importer`.
- Art direction and asset performance: `roblox-game-art`.
- Avatar creation router: `roblox-avatar-maker`.
- R15 bodies and rigging: `roblox-avatar-r15-maker`, `roblox-bodies-maker`, and `blender-rigify-roblox`.
- Accessories, clothing, makeup, emotes: `roblox-accessories-maker`, `roblox-clothing-maker`, `roblox-makeup-maker`, and `roblox-animation-emotes`.
- UGC and Marketplace submission: `roblox-ugc-marketplace`.
- Creator Store distribution: `roblox-creator-store`.
- Collaboration, Team Create, groups, permissions: `roblox-collaboration`.
- Audio pipeline and SoundService patterns: `roblox-game-audio`.
- Core loop, progression, retention: `roblox-game-design`.
- UI design, ScreenGui, mobile ergonomics: `roblox-ui-design`.
- Player-facing systems such as inventory, quests, progression, settings, and onboarding: `roblox-player-facing-systems`.
- Local multiplayer Studio validation: `roblox-studio-multiplayer-test`.

## Autonomous Execution Loop

1. Clarify goal, owner, target place/universe, and production risk.
2. Choose the minimal set of Roblox skills needed.
3. Produce a concrete plan with explicit files, services, assets, IDs, and Studio tools.
4. Implement the smallest safe slice first.
5. Verify with code checks, Studio playtests, multiplayer tests, or dashboard checks as appropriate.
6. Summarize what changed, what was verified, and what remains.

## Publish Workflow

1. Read project publish scripts and config first.
2. Prefer repo wrappers for Rojo sourcemap, smoke checks, and upload.
3. Confirm universe ID, place ID, creator/group owner, and API key scope before publish.
4. Close Studio before retrying conflicts caused by active edit sessions.
5. Record the published target and verification result.

## Standard Checklists

### Security

- Remote inputs validated on server.
- Rate limits and cooldowns exist for player-triggered remotes.
- No client-trusted currency, ownership, inventory, or paid entitlement.

### Persistence

- Backoff and retries.
- Schema versioning.
- Save queue and session ownership.

### Assets

- Asset IDs documented.
- Owner/group permissions verified.
- Imported assets tested in Play mode.

### UI

- Mobile tap targets.
- Text legibility.
- Responsive layouts.

