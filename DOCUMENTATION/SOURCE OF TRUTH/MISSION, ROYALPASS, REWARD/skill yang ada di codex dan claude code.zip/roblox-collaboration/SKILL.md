---
name: roblox-collaboration
description: "Use for Roblox collaboration workflows: Team Create, Creator Dashboard permissions, groups, roles, access control, package ownership, asset ownership, version history, publish handoff, review workflows, multi-developer Studio work, and safe coordination between artists, scripters, builders, and producers."
---

# Roblox Collaboration

Use this skill when multiple people, accounts, groups, or tools share ownership of a Roblox project.

## Workflow

1. Identify collaboration surface: Team Create, group-owned experience, package, asset upload, plugin/tooling, Creator Dashboard, or source-control repo.
2. Map roles: owner, producer, scripter, builder, artist, animator, QA, finance, ads, and release operator.
3. Grant least-privilege access through groups, roles, and project permissions.
4. Define edit boundaries: Studio objects, scripts/modules, assets, packages, places, and dashboard settings.
5. Establish versioning and rollback: Studio version history, source control, package versions, and release notes.
6. Document publish and review authority before production changes.

## Rules

- Do not share passwords or personal API keys for team work.
- Prefer group ownership for production experiences and shared assets.
- Keep source-control ownership separate from Creator Dashboard permission assumptions.
- Use package or module boundaries for reusable assets instead of copy-paste drift.
- Record who can publish, spend ad budget, change monetization products, or access finances.

## Common Tasks

- Set up Team Create and role permissions.
- Move asset ownership from personal account assumptions to group-safe workflows.
- Plan review gates for code, art, economy, ads, and monetization.
- Resolve conflicts between Studio live edits and Rojo/source-control workflows.

## Output Style

- Return a permission matrix when access control is the issue.
- Separate Studio permissions, Creator Dashboard permissions, source-control access, and financial authority.
- Flag high-risk permissions such as publishing, spending, payout, and API key management.

