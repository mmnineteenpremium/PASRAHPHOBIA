---
name: roblox-engine-reference
description: Prioritize the official Roblox Engine API reference for classes, services, properties, methods, events, enums, data types, globals, libraries, object hierarchy, and runtime behavior. Use when Codex must answer engine-specific Luau or Roblox Studio questions, map APIs to the correct class or service, verify current Roblox engine rules from create.roblox.com/docs/id-id/reference/engine, or handle Indonesian requests about Roblox engine internals.
---

# Roblox Engine Reference

Use this skill for exact engine knowledge. Start from the official Engine API reference instead of memory whenever the user asks about a Roblox type, member, runtime rule, or current engine behavior.

## Workflow

1. Classify the question as an API lookup, runtime behavior, object-hierarchy issue, or placement problem.
2. Open [references/engine-api-map.md](references/engine-api-map.md) for official doc entry points and lookup rules.
3. Open [references/runtime-boundaries.md](references/runtime-boundaries.md) when script placement, lifecycle, or execution side matters.
4. Verify against the official Roblox docs if the answer depends on current API tags, deprecations, security context, or recent platform behavior.
5. Answer with the exact type name, the relevant members, the intended runtime side, and the correct Studio container.

## Working Rules

- Use official API names and member capitalization exactly.
- Distinguish services, creatable classes, data types, enums, globals, and libraries.
- Do not assume every class can be created with `Instance.new`.
- Do not assume every property replicates, is writable, or is scriptable.
- Surface tags such as deprecated, read-only, not-replicated, or security-gated when they matter to the answer.
- If the user only describes behavior, map it to likely engine types before writing code.

## Reference Files

- Read [references/engine-api-map.md](references/engine-api-map.md) first for doc roots, lookup patterns, and answer checklists.
- Read [references/runtime-boundaries.md](references/runtime-boundaries.md) when the task depends on server, client, or shared execution.

## Output Style

- Start with the exact class, service, or API name.
- Separate server, client, and shared behavior whenever the distinction affects correctness.
- Include the official doc path when the answer depends on engine specifics.

## Example Requests

- "What is the difference between `RemoteEvent` and `RemoteFunction` in Roblox?"
- "Which service should own this system in Roblox Studio?"
- "Does this property replicate to clients?"
- "Where should this ModuleScript live if both server and client need it?"
