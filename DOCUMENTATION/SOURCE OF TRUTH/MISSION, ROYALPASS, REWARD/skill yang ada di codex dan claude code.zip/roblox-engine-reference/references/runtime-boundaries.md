# Roblox Runtime Boundaries

Use this file when the user needs correct script placement or execution-side reasoning.

## Studio Containers

- `ServerScriptService`: authoritative gameplay logic, validation, persistence orchestration, purchase fulfillment
- `ServerStorage`: server-only assets, modules, and templates that must never replicate directly
- `ReplicatedStorage`: shared modules, remotes, static shared data, assets both sides can read
- `ReplicatedFirst`: early-loading client assets or code that must run before most replication finishes
- `StarterPlayerScripts`: local input, camera, client UX orchestration
- `StarterCharacterScripts`: per-character local behavior
- `StarterGui`: UI templates and LocalScripts tied to interface
- `StarterPack`: tools that clone into the player backpack
- `Workspace`: world objects, interactables, NPC models, physics bodies

## Execution Rules

- Keep authority for currency, inventory, combat resolution, and persistence on the server.
- Treat every client payload as untrusted input.
- Explain ModuleScript placement in terms of who requires it and who owns the truth.
- Use `WaitForChild` when replicated instances may arrive asynchronously on the client.
- Keep world hierarchy and object naming explicit when the bug depends on path resolution.

## Side-Specific Reasoning

- Server: validate, simulate authoritative state, save data, grant purchases
- Client: collect input, render UX, play cosmetic effects, request actions
- Shared: hold schemas, constants, type definitions, serializers, remotes, and reusable helpers that do not own truth

## Escalation Rule

- Move to `roblox-networking-security` when the dominant issue is replication, remotes, StreamingEnabled, network ownership, or exploit resistance.
