# Roblox Engine API Map

Use this file when the user asks about a specific Roblox engine type or member.

## Official Entry Points

- Localized root: `https://create.roblox.com/docs/id-id/reference/engine`
- English fallback: `https://create.roblox.com/docs/reference/engine`
- Classes index: `https://create.roblox.com/docs/id-id/reference/engine/classes`
- Enums index: `https://create.roblox.com/docs/id-id/reference/engine/enums`
- Data types index: `https://create.roblox.com/docs/id-id/reference/engine/datatypes`
- Globals index: `https://create.roblox.com/docs/id-id/reference/engine/globals`
- Libraries index: `https://create.roblox.com/docs/id-id/reference/engine/libraries`
- Release notes: `https://create.roblox.com/docs/release-notes`

If the localized page is unavailable, remove the locale segment and use the English page with the same path.

## Lookup Routine

1. Identify whether the symbol is a class, service, enum, data type, library, or global.
2. Open the corresponding reference index.
3. Confirm the exact member signature, tags, and summary before answering.
4. Check whether the API belongs on the server, the client, or both.
5. State the correct Studio container or service for the code that uses it.

## Stable Guardrails

- Prefer `game:GetService()` for services instead of assuming a direct child lookup.
- Treat service classes and creatable classes as different concepts.
- Call out `Instance.new` constraints when a class is abstract or service-owned.
- Mention replication or security limits when a member cannot be trusted from the client.
- Flag deprecations instead of silently using outdated APIs.

## Common Engine Buckets

- World and simulation: `Workspace`, `RunService`, `PhysicsService`
- Players and session: `Players`, `Teams`, `StarterPlayer`
- Shared state and bootstrapping: `ReplicatedStorage`, `ReplicatedFirst`, `ServerStorage`
- UI and input: `StarterGui`, `GuiObject`, `UserInputService`, `ContextActionService`
- Animation and audio: `Animator`, `AnimationTrack`, `SoundService`
- Commerce and identity: `MarketplaceService`, `BadgeService`, `PolicyService`

## Answer Checklist

- Name the exact Roblox type.
- Name the relevant members.
- State the runtime side.
- State the intended Studio placement.
- Mention any tag or replication caveat that changes the implementation.
