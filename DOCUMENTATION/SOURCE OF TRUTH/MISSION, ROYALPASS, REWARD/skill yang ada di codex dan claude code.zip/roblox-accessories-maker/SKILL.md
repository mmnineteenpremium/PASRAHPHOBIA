---
name: roblox-accessories-maker
description: Use for Roblox accessory creation, hats, hair, face accessories, shoulder/back/waist items, rigid accessories, layered accessories, Accessory Fitting Tool, attachments, pivots, scale, cages/wraps, thumbnailing, UGC readiness, and troubleshooting avatar accessory fit.
---

# Roblox Accessories Maker

Use this skill for avatar accessories and wearables.

## Workflow

1. Identify accessory category: hat, hair, face, neck, shoulder, front, back, waist, rigid accessory, or layered accessory.
2. Prepare mesh scale, origin, pivot, attachment point, material, texture, and LOD/performance expectations.
3. Use the Accessory Fitting Tool or current Studio avatar tooling to fit and validate placement.
4. Test on multiple R15 body scales, heads, animations, and common clothing layers.
5. Track final asset IDs and owner/group with `roblox-asset-id-manager`.
6. Route Marketplace upload and policy checks to `roblox-ugc-marketplace`.

## Fit Checks

- Correct attachment type and placement.
- No severe clipping across common body scales.
- Pivot and bounds support clean thumbnails and preview.
- Hair and face accessories leave room for head variants where intended.
- Layered accessories have valid cage/wrap behavior when applicable.

## Debugging

- Floats away from avatar: check attachment name, offset, and scale.
- Clips badly: fit to more body scales or adjust silhouette.
- Looks huge/small in preview: verify DCC export units and Studio scale.
- Upload issue: verify category, metadata, ownership, and current eligibility requirements.

## Output Style

- State rigid versus layered accessory first.
- Give DCC prep, Studio fitting, validation, and submission steps.
- Mark exact blocker if attachment, scale, cage, or policy readiness is incomplete.
