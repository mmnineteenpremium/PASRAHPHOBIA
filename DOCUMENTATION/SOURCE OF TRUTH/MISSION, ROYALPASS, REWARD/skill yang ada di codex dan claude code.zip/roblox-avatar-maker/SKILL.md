---
name: roblox-avatar-maker
description: Use for end-to-end Roblox avatar creation across bodies, heads, R15 rigs, accessories, clothing, makeup/face textures, emotes, UGC submission planning, Avatar Setup, HumanoidDescription assembly, and in-experience avatar customization systems.
---

# Roblox Avatar Maker

Use this skill as the router for avatar creation tasks. Load the narrow skill for the actual asset type when possible.

## Routing

- R15 body or rig: `roblox-avatar-r15-maker` or `roblox-bodies-maker`.
- Accessories: `roblox-accessories-maker`.
- Classic or layered clothing: `roblox-clothing-maker`.
- Makeup, face texture, skin overlay, or cosmetic surface work: `roblox-makeup-maker`.
- Animation or emote: `roblox-animation-emotes`.
- Marketplace or UGC publishing: `roblox-ugc-marketplace`.
- Import pipeline: `roblox-studio-importer`.

## Workflow

1. Define whether the avatar asset is for in-game customization, Creator Store distribution, Marketplace/UGC, or internal tooling.
2. Identify the base rig/body, scale, style guide, and compatible clothing/accessory targets.
3. Build or import the asset with the narrow creation skill.
4. Validate fit across R15 body scales, accessories, animations, and mobile camera readability.
5. Track asset IDs and ownership with `roblox-asset-id-manager`.
6. For player customization code, treat the server as authoritative and route networking work to `roblox-networking-security`.

## Quality Bar

- Consistent scale and silhouette.
- Clean attachments, pivots, and deformation.
- No hidden copyrighted or unlicensed source art.
- Mobile-readable texture and color contrast.
- Current Roblox documentation checked before Marketplace submission.

## Output Style

- Start with the target output: body, accessory, clothing, makeup, emote, or complete avatar set.
- List required tools and validation steps in production order.
- Separate art production, Studio setup, Marketplace compliance, and runtime integration.
