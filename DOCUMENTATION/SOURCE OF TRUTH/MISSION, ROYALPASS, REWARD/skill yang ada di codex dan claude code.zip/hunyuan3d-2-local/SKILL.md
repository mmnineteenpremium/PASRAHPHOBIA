---
name: hunyuan3d-2-local
description: Install, update, launch, and debug the local Tencent Hunyuan3D-2 repo on this Windows machine. Use when Codex needs to work with `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2`, manage its `.venv`, verify Python and CUDA readiness, launch the Gradio UI or API server, troubleshoot missing native extensions, or explain the local Hunyuan3D-2 setup.
---

# Hunyuan3D 2 Local

Use this skill to operate the local Windows clone of Tencent Hunyuan3D-2 at `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2`. Prefer the bundled PowerShell scripts over retyping setup and launch commands.

## Local Facts

- Repo path: `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2`
- Virtual environment: `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2\.venv`
- Verified on April 17, 2026: base Python environment installs successfully; `hy3dgen`, `hy3dgen.shapegen`, and `hy3dgen.texgen` import successfully; `gradio_app.py --help` and `api_server.py --help` succeed.
- Current machine limits on April 17, 2026: `torch.cuda.is_available()` is `False`; `cl` is missing; `nvcc` is missing; `mesh_processor` and `custom_rasterizer_kernel` are not built.
- Read [references/local-install.md](references/local-install.md) when you need the exact machine-state details before making claims about runtime support.

## Workflow

### Reinstall or Refresh the Environment

- Run `scripts/bootstrap.ps1`.
- Use `-RecreateVenv` when dependency state looks broken or mismatched.
- Use `-BuildDifferentiableRenderer` only when `cl` is available.
- Use `-BuildCustomRasterizer` only when both `cl` and `nvcc` are available.

### Check Readiness Before Claiming Support

- Run `scripts/smoke-test.ps1`.
- Treat `torch.cuda.is_available() == False` as CPU-only.
- Do not claim texture or rasterizer support unless the smoke test shows the required native modules or toolchain.
- Distinguish three states clearly: base Python install works, CLI entrypoints work, full model inference is ready.

### Launch the Gradio UI

- Run `scripts/run-gradio.ps1`.
- Default to `-Variant mini-turbo` for lighter local testing unless the user explicitly wants another checkpoint.
- Valid variants: `mini`, `mini-turbo`, `mv`, `mv-turbo`, `base`, `base-turbo`.
- Let the script auto-detect the device unless the user explicitly wants `-Device cpu` or `-Device cuda`.
- Use `-Preview` when you want the fully resolved launch command without starting the server.
- On this machine, expect the auto-detected device to be `cpu` until CUDA becomes available.

### Launch the API Server

- Run `scripts/run-api.ps1`.
- The upstream API server defaults to `tencent/Hunyuan3D-2mini`; keep that default unless the user asks for another model.
- Use `-EnableTex` only when texturing is required and the environment is ready for the slower path.
- Use `-Preview` when you only need the resolved command line.
- On CPU, keep concurrency low.

### Use the Python APIs

- Run from repo root with `.venv\Scripts\python`.
- Use `minimal_demo.py`, `api_server.py`, `gradio_app.py`, and the `examples\` folder as starting points.
- Expect first real runs to download large checkpoints from Hugging Face.
- State plainly that CPU execution may be impractical for full inference.

## Constraints

- `hy3dgen\texgen\differentiable_renderer\setup.py` requires a working C++ compiler.
- `hy3dgen\texgen\custom_rasterizer\setup.py` requires CUDA toolkit and `nvcc`.
- The upstream repository advertises Windows support, but the current local machine is CPU-only as of April 17, 2026.
- Surface the Tencent Hunyuan non-commercial license if the user asks about commercial use or redistribution.

## Scripts

- `scripts/bootstrap.ps1`: create or refresh `.venv` and install `hy3dgen` in editable mode.
- `scripts/smoke-test.ps1`: report Python, import, CLI, and toolchain readiness.
- `scripts/run-gradio.ps1`: launch Gradio with preset model variants.
- `scripts/run-api.ps1`: launch the local API server with sane CPU-aware defaults.

## Example Requests

- "Set up the local Hunyuan3D-2 repo again."
- "Launch the Hunyuan3D Gradio UI on this machine."
- "Why does Hunyuan3D texturing fail locally?"
- "Check whether CUDA and the custom rasterizer are ready."
- "Start the local API server for Hunyuan3D-2mini."
