param(
    [string]$RepoPath = "C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2",
    [string]$ModelPath = "tencent/Hunyuan3D-2mini",
    [string]$TexModelPath = "tencent/Hunyuan3D-2",
    [ValidateSet("auto", "cpu", "cuda")]
    [string]$Device = "auto",
    [int]$Port = 8081,
    [string]$BindHost = "127.0.0.1",
    [int]$LimitModelConcurrency = 1,
    [switch]$EnableTex,
    [switch]$Preview
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-Device {
    param(
        [string]$PythonExe,
        [string]$Requested
    )

    if ($Requested -ne "auto") {
        return $Requested
    }

    $detected = & $PythonExe -c "import torch; print('cuda' if torch.cuda.is_available() else 'cpu')"
    if ($LASTEXITCODE -ne 0) {
        throw "Unable to detect torch device."
    }

    return $detected.Trim()
}

if (-not (Test-Path -LiteralPath $RepoPath)) {
    throw "Repo path not found: $RepoPath"
}

$pythonExe = Join-Path $RepoPath ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $pythonExe)) {
    throw "Virtual environment Python not found: $pythonExe"
}

$resolvedDevice = Resolve-Device -PythonExe $pythonExe -Requested $Device

$args = @(
    "api_server.py",
    "--host", $BindHost,
    "--port", $Port.ToString(),
    "--model_path", $ModelPath,
    "--tex_model_path", $TexModelPath,
    "--device", $resolvedDevice,
    "--limit-model-concurrency", $LimitModelConcurrency.ToString()
)

if ($EnableTex) {
    $args += "--enable_tex"
}

Write-Host ("Launching API server with model '{0}' on device '{1}'." -f $ModelPath, $resolvedDevice)
Write-Host ("Command: {0} {1}" -f $pythonExe, ($args -join " "))

if ($Preview) {
    exit 0
}

Push-Location $RepoPath
try {
    & $pythonExe @args
    if ($LASTEXITCODE -ne 0) {
        throw "API server launch failed."
    }
}
finally {
    Pop-Location
}
