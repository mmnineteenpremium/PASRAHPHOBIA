param(
    [string]$RepoPath = "C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
if (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue) {
    $PSNativeCommandUseErrorActionPreference = $false
}

if (-not (Test-Path -LiteralPath $RepoPath)) {
    throw "Repo path not found: $RepoPath"
}

$pythonExe = Join-Path $RepoPath ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $pythonExe)) {
    throw "Virtual environment Python not found: $pythonExe"
}

$pythonProbe = @'
import importlib
import json
import subprocess
import sys

status = {
    "python": sys.version.split()[0],
}

try:
    import torch
    status["torch"] = torch.__version__
    status["cuda_available"] = bool(torch.cuda.is_available())
    status["cuda_version"] = torch.version.cuda
except Exception as exc:
    status["torch_error"] = f"{type(exc).__name__}: {exc}"

def probe(module_name):
    try:
        importlib.import_module(module_name)
        return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

core_modules = [
    "hy3dgen",
    "hy3dgen.shapegen",
    "hy3dgen.texgen",
]

optional_modules = [
    "mesh_processor",
    "custom_rasterizer_kernel",
]

for name in core_modules + optional_modules:
    status[name] = probe(name)

cli_checks = {
    "gradio_help": ["gradio_app.py", "--help"],
    "api_help": ["api_server.py", "--help"],
}

for name, args in cli_checks.items():
    result = subprocess.run(
        [sys.executable, *args],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    status[name] = {"ok": result.returncode == 0}

print(json.dumps(status, indent=2))

core_ok = all(status[name]["ok"] for name in core_modules)
cli_ok = all(status[name]["ok"] for name in cli_checks)
sys.exit(0 if core_ok and cli_ok else 1)
'@

Write-Host "Python import status:"
Push-Location $RepoPath
try {
    $pythonProbe | & $pythonExe -
    $hasFailure = ($LASTEXITCODE -ne 0)
}
finally {
    Pop-Location
}

$clStatus = if (Get-Command cl -ErrorAction SilentlyContinue) { "present" } else { "missing" }
$nvccStatus = if (Get-Command nvcc -ErrorAction SilentlyContinue) { "present" } else { "missing" }

Write-Host ""
Write-Host "Toolchain:"
Write-Host ("- cl: {0}" -f $clStatus)
Write-Host ("- nvcc: {0}" -f $nvccStatus)

if ($hasFailure) {
    exit 1
}
