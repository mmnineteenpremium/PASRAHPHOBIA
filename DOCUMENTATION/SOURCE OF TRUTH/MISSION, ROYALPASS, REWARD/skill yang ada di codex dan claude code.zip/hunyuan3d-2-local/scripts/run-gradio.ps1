param(
    [string]$RepoPath = "C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2",
    [ValidateSet("mini", "mini-turbo", "mv", "mv-turbo", "base", "base-turbo")]
    [string]$Variant = "mini-turbo",
    [ValidateSet("auto", "cpu", "cuda")]
    [string]$Device = "auto",
    [int]$Port = 8080,
    [string]$BindHost = "127.0.0.1",
    [string]$CachePath = "gradio_cache",
    [string]$McAlgo = "mc",
    [switch]$DisableTex,
    [switch]$EnableT23D,
    [switch]$Compile,
    [switch]$NoLowVramMode,
    [switch]$Preview
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-Device {
    param(
        [string]$PythonExe,
        [string]$Requested
    )

    if ($Requested -ne "auto") {
        return $Requested
    }

    $detected = & $PythonExe -c "import torch; print('cuda' if torch.cuda.is_available() else 'cpu')"
    if ($LASTEXITCODE -ne 0) {
        throw "Unable to detect torch device."
    }

    return $detected.Trim()
}

if (-not (Test-Path -LiteralPath $RepoPath)) {
    throw "Repo path not found: $RepoPath"
}

$pythonExe = Join-Path $RepoPath ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $pythonExe)) {
    throw "Virtual environment Python not found: $pythonExe"
}

$variants = @{
    "mini" = @{ ModelPath = "tencent/Hunyuan3D-2mini"; Subfolder = "hunyuan3d-dit-v2-mini"; FlashVdm = $false }
    "mini-turbo" = @{ ModelPath = "tencent/Hunyuan3D-2mini"; Subfolder = "hunyuan3d-dit-v2-mini-turbo"; FlashVdm = $true }
    "mv" = @{ ModelPath = "tencent/Hunyuan3D-2mv"; Subfolder = "hunyuan3d-dit-v2-mv"; FlashVdm = $false }
    "mv-turbo" = @{ ModelPath = "tencent/Hunyuan3D-2mv"; Subfolder = "hunyuan3d-dit-v2-mv-turbo"; FlashVdm = $true }
    "base" = @{ ModelPath = "tencent/Hunyuan3D-2"; Subfolder = "hunyuan3d-dit-v2-0"; FlashVdm = $false }
    "base-turbo" = @{ ModelPath = "tencent/Hunyuan3D-2"; Subfolder = "hunyuan3d-dit-v2-0-turbo"; FlashVdm = $true }
}

$config = $variants[$Variant]
$resolvedDevice = Resolve-Device -PythonExe $pythonExe -Requested $Device

$args = @(
    "gradio_app.py",
    "--model_path", $config.ModelPath,
    "--subfolder", $config.Subfolder,
    "--texgen_model_path", "tencent/Hunyuan3D-2",
    "--port", $Port.ToString(),
    "--host", $BindHost,
    "--device", $resolvedDevice,
    "--mc_algo", $McAlgo,
    "--cache-path", $CachePath
)

if (-not $NoLowVramMode) {
    $args += "--low_vram_mode"
}
if ($DisableTex) {
    $args += "--disable_tex"
}
if ($EnableT23D) {
    $args += "--enable_t23d"
}
if ($Compile) {
    $args += "--compile"
}
if ($config.FlashVdm -and $resolvedDevice -eq "cuda") {
    $args += "--enable_flashvdm"
}
elseif ($config.FlashVdm) {
    Write-Warning "Skipping --enable_flashvdm because CUDA is not available."
}

Write-Host ("Launching Gradio with variant '{0}' on device '{1}'." -f $Variant, $resolvedDevice)
Write-Host ("Command: {0} {1}" -f $pythonExe, ($args -join " "))

if ($Preview) {
    exit 0
}

Push-Location $RepoPath
try {
    & $pythonExe @args
    if ($LASTEXITCODE -ne 0) {
        throw "Gradio launch failed."
    }
}
finally {
    Pop-Location
}
