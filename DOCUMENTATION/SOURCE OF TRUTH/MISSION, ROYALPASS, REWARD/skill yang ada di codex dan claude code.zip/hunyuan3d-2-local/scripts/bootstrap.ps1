param(
    [string]$RepoPath = "C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2",
    [string]$BootstrapPython = "C:\Python310\python.exe",
    [switch]$RecreateVenv,
    [switch]$BuildDifferentiableRenderer,
    [switch]$BuildCustomRasterizer
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Invoke-Step {
    param(
        [string[]]$Command
    )

    Write-Host (">> " + ($Command -join " "))
    $exe = $Command[0]
    $args = @()
    if ($Command.Count -gt 1) {
        $args = $Command[1..($Command.Count - 1)]
    }

    & $exe @args
    if ($LASTEXITCODE -ne 0) {
        throw ("Command failed with exit code {0}: {1}" -f $LASTEXITCODE, ($Command -join " "))
    }
}

if (-not (Test-Path -LiteralPath $RepoPath)) {
    throw "Repo path not found: $RepoPath"
}

if (-not (Test-Path -LiteralPath $BootstrapPython)) {
    throw "Bootstrap Python not found: $BootstrapPython"
}

$venvPath = Join-Path $RepoPath ".venv"
$pythonExe = Join-Path $venvPath "Scripts\python.exe"

if ($RecreateVenv -and (Test-Path -LiteralPath $venvPath)) {
    Write-Host "Removing existing virtual environment."
    Remove-Item -LiteralPath $venvPath -Recurse -Force
}

if (-not (Test-Path -LiteralPath $venvPath)) {
    Invoke-Step -Command @($BootstrapPython, "-m", "venv", $venvPath)
}

if (-not (Test-Path -LiteralPath $pythonExe)) {
    throw "Virtual environment Python not found: $pythonExe"
}

Push-Location $RepoPath
try {
    Invoke-Step -Command @($pythonExe, "-m", "pip", "install", "--upgrade", "pip")
    Invoke-Step -Command @($pythonExe, "-m", "pip", "install", "-r", "requirements.txt")
    Invoke-Step -Command @($pythonExe, "-m", "pip", "install", "-e", ".")

    if ($BuildDifferentiableRenderer) {
        if (-not (Get-Command cl -ErrorAction SilentlyContinue)) {
            throw "Cannot build differentiable renderer because cl.exe is not available."
        }

        Push-Location (Join-Path $RepoPath "hy3dgen\texgen\differentiable_renderer")
        try {
            Invoke-Step -Command @($pythonExe, "setup.py", "install")
        }
        finally {
            Pop-Location
        }
    }

    if ($BuildCustomRasterizer) {
        if (-not (Get-Command cl -ErrorAction SilentlyContinue)) {
            throw "Cannot build custom rasterizer because cl.exe is not available."
        }
        if (-not (Get-Command nvcc -ErrorAction SilentlyContinue)) {
            throw "Cannot build custom rasterizer because nvcc is not available."
        }

        Push-Location (Join-Path $RepoPath "hy3dgen\texgen\custom_rasterizer")
        try {
            Invoke-Step -Command @($pythonExe, "setup.py", "install")
        }
        finally {
            Pop-Location
        }
    }
}
finally {
    Pop-Location
}

Write-Host ""
Write-Host "Bootstrap complete."
Write-Host "Repo: $RepoPath"
Write-Host "Venv Python: $pythonExe"
