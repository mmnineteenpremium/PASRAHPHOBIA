# Local Install State

## Verified On

- April 17, 2026

## Local Paths

- Repo: `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2`
- Virtual environment: `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2\.venv`
- Venv Python: `C:\AI\3D HUNYUAN TENCENT\Hunyuan3D-2\.venv\Scripts\python.exe`

## Commands Already Run

1. `git clone https://github.com/Tencent-Hunyuan/Hunyuan3D-2.git`
2. `py -3.10 -m venv .venv`
3. `.\.venv\Scripts\python -m pip install --upgrade pip`
4. `.\.venv\Scripts\python -m pip install -r requirements.txt`
5. `.\.venv\Scripts\python -m pip install -e .`

## Verified Results

- Base package install completed successfully in the local `.venv`.
- `hy3dgen` import succeeds.
- `from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline` succeeds.
- `from hy3dgen.texgen import Hunyuan3DPaintPipeline` succeeds.
- `python gradio_app.py --help` exits successfully.
- `python api_server.py --help` exits successfully.
- `api_server.py --help` emits a `Siglip2ImageProcessorFast` deprecation warning but still succeeds.
- Venv `torch` version on April 17, 2026: `2.11.0+cpu`
- Venv CUDA availability on April 17, 2026: `False`
- Venv CUDA runtime version on April 17, 2026: `None`

## Missing Native Pieces

- `cl`: missing
- `nvcc`: missing
- `mesh_processor`: not built
- `custom_rasterizer_kernel`: not built

## Operational Interpretation

- The local Python environment is ready for imports and entrypoint parsing.
- First real inference will trigger model downloads from Hugging Face.
- This machine is currently CPU-only, so full generation will be slow or impractical.
- Treat differentiable renderer and custom rasterizer support as incomplete until build tools are installed and the optional extensions are built successfully.
- If commercial use comes up, surface the upstream Tencent Hunyuan non-commercial license before proceeding.
