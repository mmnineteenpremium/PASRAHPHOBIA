---
name: roblox-studio-multiplayer-test
description: Run and document Roblox Studio local multiplayer smoke tests, especially `Server + 2 Clients`, when you need stable multi-window layouts, exact screenshots with metadata, or OS-level fallback because unnamed Studio instances are not attachable through MCP.
---

# Roblox Studio Multiplayer Test

Use this skill for Roblox Studio local multiplayer prechecks, not for final publish sign-off on real Roblox clients.

## Workflow

1. Confirm scope first.
- This skill is for local Studio validation such as `Server + 2 Clients`, room flow smoke, or multi-window screenshot evidence.
- It does not replace final publish checks on two real Roblox clients.

2. Enumerate Studio state twice.
- Use `mcp__Roblox_Studio__list_roblox_studios` to see what Roblox MCP exposes.
- Use `scripts/window-automation.ps1 list` to see the actual Windows-level Studio windows and their bounds.

3. Choose the control plane.
- If the main named Studio is attachable, keep MCP on that main Studio for script edits, Luau probes, and console output.
- If child test windows are unnamed or `execute_luau` starts failing after `set_active_studio`, treat those child windows as OS-automation only.
- Do not waste time trying to force unnamed child windows through MCP once they show disconnected behavior.

4. Normalize layout before capturing or clicking.
- Either preserve the current window bounds with `describe`, or move the windows into fixed slots before testing.
- Avoid overlapping windows. Overlap makes screenshots ambiguous and input unreliable.
- After `move`, `focus`, or `click`, wait roughly `300-800ms` before the next screenshot or keypress.

5. Capture exact screenshots with metadata.
- Default to `CaptureArea client`.
- `client` capture includes the visible Roblox Studio UI and panels, but excludes the outer OS frame.
- Every capture writes a sidecar JSON containing `WindowBounds`, `ClientBounds`, and `CaptureBounds`.
- Use `CaptureArea window` only if the OS frame or title bar matters to the evidence.

6. Prefer a Studio-only smoke harness for room flow.
- For repeated `Server + 2 Clients` smoke, use a temporary `StarterPlayerScripts` LocalScript guarded by:
  - `RunService:IsStudio()`
  - a `ReplicatedStorage` attribute flag such as `PasrahAutoRoomSmoke`
- Use the existing room browser controller / lobby remote flow instead of inventing ad hoc remotes.
- A reliable host/join split is:
  - host: `SelectMode`, `SelectMap`, `CreateRoom`, then `HostStart`
  - joiner: `RequestSnapshot`, `RequestRoomList`, `JoinRoom`, then `SetReady(true)`

7. Teardown matters.
- Disable the Studio smoke attributes after verification.
- Stop play or kill spawned child Studio windows so the next run starts from a clean state.
- Keep screenshots plus sidecar JSON if they are part of the test evidence.

## Exact Screenshot Rule

Treat the sidecar JSON as part of the screenshot artifact. The PNG alone is not enough if you need the capture to be reproducible.

Validated example from the current Windows Studio session:
- `WindowBounds`: `Left=0`, `Top=0`, `Width=1720`, `Height=720`
- `ClientBounds`: `Left=8`, `Top=31`, `Width=1704`, `Height=681`
- `CaptureArea client` reproduces a `1704x681` image
- `CaptureArea window` reproduces a `1720x720` image

When the user says the screenshot must match the current Studio window exactly, preserve these bounds first, then capture.

## Resources

- `scripts/window-automation.ps1`: Windows-level listing, moving, focusing, clicking, and screenshot capture with JSON metadata.
- `references/workflow.md`: fixed layout coordinates, reliable commands, harness pattern, and pass/fail interpretation.
- `references/studio-room-smoke-example.lua`: Studio-only LocalScript example for host/join/ready/start automation in local smoke runs.
