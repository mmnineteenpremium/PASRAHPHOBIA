# Workflow Reference

## 1. Enumerate Windows

Use both layers:

```powershell
pwsh -File scripts/window-automation.ps1 list
```

And Roblox MCP:
- `list_roblox_studios`
- `set_active_studio`
- `get_console_output`

Interpretation:
- named main Studio: MCP-friendly if the place is still attached
- unnamed `Server` / `Place1` test windows: often visible to MCP but not stable enough for `execute_luau`
- once unnamed instances start returning disconnect/place-open errors, stop trying to use them through MCP

## 2. Stable Window Layout

A reliable tiled layout on a 3440x1440 desktop is:

- main Studio: `X=0`, `Y=0`, `Width=1720`, `Height=720`
- server: `X=1720`, `Y=0`, `Width=1720`, `Height=720`
- client A: `X=0`, `Y=720`, `Width=1720`, `Height=720`
- client B: `X=1720`, `Y=720`, `Width=1720`, `Height=720`

Example:

```powershell
pwsh -File scripts/window-automation.ps1 move -WindowPid 23284 -X 0 -Y 0 -Width 1720 -Height 720
pwsh -File scripts/window-automation.ps1 move -WindowPid 10152 -X 1720 -Y 0 -Width 1720 -Height 720
pwsh -File scripts/window-automation.ps1 move -WindowPid 8988 -X 0 -Y 720 -Width 1720 -Height 720
pwsh -File scripts/window-automation.ps1 move -WindowPid 26936 -X 1720 -Y 720 -Width 1720 -Height 720
```

## 3. Exact Screenshot Commands

Describe first if you need proof of current bounds:

```powershell
pwsh -File scripts/window-automation.ps1 describe -WindowPid 23284 -CaptureArea client
```

Default exact UI capture:

```powershell
pwsh -File scripts/window-automation.ps1 capture -WindowPid 23284 -CaptureArea client -OutPath .\roblox_studio_current_client.png
```

Full outer window capture:

```powershell
pwsh -File scripts/window-automation.ps1 capture -WindowPid 23284 -CaptureArea window -OutPath .\roblox_studio_current_window.png
```

Each capture writes:
- PNG file
- JSON sidecar with window/client/capture bounds

Use the sidecar JSON to reproduce the same capture later.

## 4. Reliable Local Multiplayer Smoke Pattern

If clicking the room browser manually is noisy or brittle, create a temporary Studio-only harness LocalScript in `StarterPlayerScripts`.

Guard it with:
- `RunService:IsStudio()`
- `ReplicatedStorage:GetAttribute("PasrahAutoRoomSmoke") == true`

Reliable behavior:
- `Player1`
  - request snapshot + room list
  - select mode/map
  - create room
  - host start when both players are present and ready
- `Player2`
  - request snapshot + room list
  - join the first joinable room
  - set ready true

This is for local smoke only. Disable it immediately after verification.

## 5. Local PASS vs Publish PASS

Local precheck PASS means:
- both Studio clients transition into the same room or the same match interior
- no new fatal runtime errors appear in server console
- evidence is captured with stable layout/screenshots

Local precheck does not mean final publish PASS.

Final publish gate still needs:
- two real Roblox clients
- non-mock persistence validation
- final legal/compliance visual review

## 6. Common Failure Modes

- Child test windows overlap: move them before capturing or clicking.
- Input goes to Studio shell instead of game viewport: click inside the viewport first.
- Roblox test menu stays open in the client: close it before sending game hotkeys.
- `start_stop_play` only starts main runtime: use toolbar click automation to spawn `Server + 2 Clients` if needed.
- MCP can list unnamed windows but still fail to execute Luau: keep MCP attached to main Studio and drive child windows through Windows automation.
