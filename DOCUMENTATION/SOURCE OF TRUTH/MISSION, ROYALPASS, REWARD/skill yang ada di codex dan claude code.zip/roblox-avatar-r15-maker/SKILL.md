---
name: roblox-avatar-r15-maker
description: Use for Roblox R15 avatar body work, Humanoid rigs, bone and attachment requirements, Avatar Setup, body/head validation, rigging in Blender for Roblox, R15 animation compatibility, HumanoidDescription assembly, and converting humanoid models into Roblox-ready R15 avatars.
---

# Roblox R15 Avatar Maker

Use this skill for R15-specific avatar bodies, rigs, and animation compatibility.

## Workflow

1. Determine target: playable in-experience character, Marketplace avatar body, NPC, or internal test rig.
2. Confirm R15 structure, scale, attachments, skinning, body part separation, and Humanoid compatibility.
3. For external rigging or FBX cleanup, use `blender-rigify-roblox` before Studio import.
4. Import with `roblox-studio-importer`, then use Avatar Setup or validation tools as appropriate.
5. Test default Roblox animations, custom animations, emotes, scaling, accessories, and layered clothing fit.
6. Route Marketplace submission and policy checks to `roblox-ugc-marketplace`.

## R15 Checks

- Body parts align with the intended R15 proportions and joints.
- Attachments are present and named consistently for accessories and animation support.
- Skin weights deform cleanly at shoulders, hips, neck, wrists, ankles, and face/head transitions.
- HumanoidRootPart, rig scale, and collision bounds are suitable for gameplay.
- Animations use the expected rig type and do not assume missing bones.

## Anti-Patterns

- Do not call a model R15-ready just because it has a humanoid shape.
- Do not skip animation tests on mobile-scale camera distances.
- Do not publish avatar bodies without checking current Roblox avatar requirements and moderation rules.

## Output Style

- Separate DCC rigging tasks, Studio import tasks, and validation tasks.
- State whether the work is for Marketplace compliance or only for an in-game character.
- Flag exact blockers: missing attachments, bad weights, wrong hierarchy, wrong scale, or incompatible animations.
