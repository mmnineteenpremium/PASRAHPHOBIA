---
name: roblox-ads
description: "Use for Roblox advertising and promotion: Ads Manager, sponsored experiences/items, immersive ads, campaign planning, ad creatives, budgets, attribution, targeting, safety policy, performance analysis, ROAS, CPI/CPA proxies, and distinguishing paid promotion from in-experience monetization implementation."
---

# Roblox Ads

Use this skill for promotion strategy, paid campaigns, and ad performance analysis.

## Workflow

1. Identify objective: acquire players, promote an experience, promote avatar/UGC items, re-engage players, or monetize through immersive ads.
2. Define audience, budget, date range, creative variants, target experience/item, and success metric.
3. Verify current Ads Manager, sponsored ad, and immersive ad rules in official Roblox docs before spend or implementation.
4. For campaign spend, track impressions, clicks/visits, CTR, cost, acquisition proxy, retention, payer conversion, and revenue impact.
5. For immersive ads inside an experience, route implementation details through `roblox-monetization` and policy checks through official docs.
6. Review finance impact with `roblox-creator-finances`.

## Creative Rules

- Match the promise in the ad to the actual landing experience or item.
- Test a small set of distinct creative angles rather than tiny cosmetic variations.
- Avoid misleading thumbnails, age-inappropriate messaging, or restricted claims.
- Use mobile-readable text and simple visual hierarchy.

## Measurement

- Separate platform ad metrics from game analytics.
- Judge acquisition by retained players, not raw visits only.
- Treat ROAS carefully when revenue attribution is incomplete.
- Compare cohorts by campaign dates and landing version.

## Output Style

- State objective, budget, audience, creative, and measurement plan.
- Provide a conservative test plan before scaling spend.
- Mark policy, targeting, and finance assumptions explicitly.

