---
name: roblox-ui-design
description: "Roblox UI design for ScreenGui/Frames: hierarchy, spacing, typography, and mobile ergonomics in Roblox."
---

# Roblox UI Design

ROBLOX-FOCUS:
- Build for mobile-first, then scale up for desktop.
- Use Roblox UI primitives: `ScreenGui`, `Frame`, `TextLabel`, `TextButton`, `ImageLabel`.
- Prefer layout components: `UIListLayout`, `UIGridLayout`, `UIPadding`, `UIScale`.

Implementation Notes (Roblox):
- Avoid tiny text; test with multiple device sizes.
- Use consistent scaling: `UIScale` and/or `TextScaled` with constraints.
- Ensure input works for touch, mouse, and gamepad when relevant.

# UI Design

Design the visible interface layer: screens, components, hierarchy, states, and readability.

## Workflow

1. Identify the screen type, platform, viewport, and user task.
2. Define the information hierarchy before styling details.
3. Build the layout using grid, spacing, grouping, and clear focal points.
4. Specify component states such as default, hover, active, disabled, loading, and error.
5. Keep typography, contrast, and spacing consistent with the intended system.
6. Read [references/ui-checklist.md](references/ui-checklist.md) when you need a fast review pass or handoff checklist.

## Working Rules

- Prioritize clarity over decorative noise.
- State what should be primary, secondary, and tertiary on the screen.
- Treat empty, error, and loading states as required parts of the design.
- Do not drift into UX architecture unless the flow itself is broken.
- Include implementation-facing details when the user needs a handoff, not only visual suggestions.

## Output Style

- Start with screen goal and hierarchy.
- Give layout decisions before color or stylistic refinements.
- When useful, provide component-by-component notes and state behavior.

## Example Requests

- "Help me design a game settings menu UI."
- "Review this dashboard UI hierarchy."
- "Define component states for this form."
- "Make this UI cleaner and easier to scan."


