# UI Checklist

Use this reference for quick UI reviews and handoff notes.

## Core Review

- Clear visual hierarchy
- Consistent spacing
- Readable typography
- Strong contrast where needed
- Obvious primary action
- Secondary actions de-emphasized correctly

## Required States

- Default
- Hover
- Active or pressed
- Focus
- Disabled
- Loading
- Error
- Empty

## Handoff Notes

- Screen dimensions or breakpoints
- Color tokens
- Typography tokens
- Spacing scale
- Component names and variants
