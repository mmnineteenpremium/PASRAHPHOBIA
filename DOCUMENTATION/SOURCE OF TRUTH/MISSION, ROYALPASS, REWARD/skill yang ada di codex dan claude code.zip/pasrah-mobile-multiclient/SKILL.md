---
name: pasrah-mobile-multiclient
description: "Coordinate PASRAHPHOBIA local multiplayer work with real mobile devices through mobile-mcp, Roblox Studio MCP, and Rojo live sync. Use when Codex needs to validate two-client flows on Samsung N960 + iPhone 14 Pro Max, keep Roblox Studio attached, or run the PASRAHPHOBIA mobile multiplayer dev loop."
---

# PASRAH Mobile Multiclient

Use this skill only for the local PASRAHPHOBIA workflow at `C:\Projects\ROBLOX\PASRAHPHOBIA`.

## Scope

- Keep `Roblox_Studio` as the authority for Studio edits, Explorer inspection, and Luau execution.
- Use `mobile-mcp-android` and `mobile-mcp-ios` for real-device screenshots, taps, app launch, and device-side validation.
- Use Rojo only for source sync and build artifacts.

## Preconditions

1. Work from `C:\Projects\ROBLOX\PASRAHPHOBIA`.
2. Run `pwsh -NoLogo -File scripts/cleanup-legacy-emulator-stack.ps1`.
3. Run `pwsh -NoLogo -File scripts/resolve-mobile-mcp-stack.ps1 -Strict`.
4. If live sync is needed, start `pwsh -NoLogo -File scripts/serve-rojo.ps1`.
5. Confirm MCP servers are available in the session:
- `Roblox_Studio`
- `mobile-mcp-android`
- `mobile-mcp-ios`

## Device Mapping

Resolve the active mapping from `scripts/resolve-mobile-mcp-stack.ps1`.

- `Samsung-N960` -> model prefix `SM-N960`
- `iPhone-14-Pro-Max` -> `ProductType` `iPhone15,3` or name match `iPhone 14 Pro Max`

Do not hardcode `emulator-*` IDs. Always target physical IDs returned by the resolver output.

## Workflow

1. Inspect or edit game logic through `Roblox_Studio`.
2. Keep server-authoritative behavior in mind. Use Android+iOS clients to validate actual client UX and replicated outcomes, not server trust boundaries.
3. Before Android actions, run `pwsh -NoLogo -File scripts/require-mobile-lane.ps1 -Lane android`.
4. Before iOS actions, run `pwsh -NoLogo -File scripts/require-mobile-lane.ps1 -Lane ios`.
5. Before dual-client actions, run `pwsh -NoLogo -File scripts/require-mobile-lane.ps1 -Lane both`.
6. Use `mobile_list_available_devices` on the relevant MCP server before any device action, then target resolved physical device IDs.
7. Treat `Samsung-N960` as client A and `iPhone-14-Pro-Max` as client B unless the task explicitly needs the reverse.
8. Preserve Rojo sync for code changes:
- `scripts/serve-rojo.ps1`
- `Rojo: Sourcemap (Watch)` task
9. Use `scripts/window-automation.ps1` when Roblox Studio child windows must be arranged or captured at OS level.

## Quick Commands

- Cleanup legacy stack: `pwsh -NoLogo -File scripts/cleanup-legacy-emulator-stack.ps1`
- Device stack check: `pwsh -NoLogo -File scripts/resolve-mobile-mcp-stack.ps1 -Strict`
- Lane gate check: `pwsh -NoLogo -File scripts/require-mobile-lane.ps1 -Lane both`
- Rojo live sync: `pwsh -NoLogo -File scripts/serve-rojo.ps1`
- Studio snapshot pull: `pwsh -NoLogo -File scripts/pull-from-studio.ps1`

## Guardrails

- Never trust client-side Android or iOS observations over server-side Studio state.
- Prefer MCP tool calls over blind coordinate taps when UI hierarchy is available.
- If either physical device is missing, stop immediately and repair the device stack before continuing.
- Never assume device continuity. Re-run lane gate checks whenever switching lane or after any cable reconnect.
- When validating a two-client flow, record which alias performed each action so evidence stays attributable.
