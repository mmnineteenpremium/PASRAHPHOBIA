# Roblox Networking Checklist

Use this file when the dominant problem is replication, remotes, or exploit resistance.

## Official Entry Points

- Engine reference root: `https://create.roblox.com/docs/id-id/reference/engine`
- Monetization and networking tasks still rely on engine types such as `RemoteEvent`, `RemoteFunction`, and service classes under the engine reference.
- Use the English fallback path if the localized page is unavailable.

## Architecture Flow

1. Client observes state and sends intent.
2. Server validates the request against authoritative state.
3. Server mutates state only after validation.
4. Server replicates the result or emits a remote message for presentation.

## Remote Selection

- Use `RemoteEvent` for one-way intent or notifications.
- Use `RemoteFunction` only when a direct response is required and blocking is acceptable.
- Avoid relying on the client as the only source of truth for any gameplay outcome.

## Anti-Exploit Rules

- Never trust client claims about currency, inventory, damage, cooldown completion, or unlock status.
- Recompute critical checks on the server.
- Throttle spam-prone remotes.
- Prefer server-generated identifiers and timestamps for transactional flows.
- Log or surface validation failures when debugging repeated exploit attempts.

## Replication Pitfalls

- Wrong container path or missing `WaitForChild` on the client
- Handler placed in the wrong script type or service
- `RemoteFunction` deadlocks or unnecessary synchronous waits
- Physics jitter from incorrect network ownership
- Missing `StreamingEnabled` handling for partially loaded worlds

## Placement Defaults

- Remotes: `ReplicatedStorage`
- Client handlers: `StarterPlayerScripts`, `StarterGui`, or tool-local LocalScripts
- Server handlers: `ServerScriptService`
- Shared message schemas and constants: `ReplicatedStorage`
