---
name: roblox-networking-security
description: Design and debug Roblox client-server architecture with correct replication, remotes, network ownership, StreamingEnabled behavior, and anti-exploit boundaries. Use when Codex needs help with RemoteEvents, RemoteFunctions, authoritative server design, replication bugs, security validation, or Indonesian requests about Roblox networking and exploit resistance.
---

# Roblox Networking Security

Use this skill when the hard part is the boundary between client and server. Optimize for correctness first, then for bandwidth, latency, and UX.

## Workflow

1. Identify the authoritative owner of the state in question.
2. Open [references/networking-checklist.md](references/networking-checklist.md) for remote-selection, validation, and replication rules.
3. If an exact member or class lookup is needed, open the sibling `roblox-engine-reference` skill for the API details.
4. Design or debug the flow from client intent to server validation to replicated outcome.
5. Explain both the code path and the Studio placement for each script, remote, and module.

## Working Rules

- Keep authority for currency, inventory, combat resolution, cooldowns, and persistence on the server.
- Use remotes to send intent, not trust.
- Validate player identity, ownership, proximity, cooldowns, and state transitions on the server.
- Minimize payload size and replication frequency.
- Avoid `RemoteFunction` in hot paths when an async server response is acceptable.
- Call out `StreamingEnabled` or network-ownership issues when they change observability or physics behavior.

## Reference Files

- Read [references/networking-checklist.md](references/networking-checklist.md) for architecture, anti-exploit, and debugging rules.

## Output Style

- Separate client, server, and shared responsibilities.
- Name the remote objects and where they should live.
- State which checks are required before the server mutates state.

## Example Requests

- "My `RemoteEvent` fires but the server ignores the action."
- "How do I stop exploiters from spoofing damage in Roblox?"
- "Why is physics ownership causing jitter for this projectile?"
- "Should this system use `RemoteEvent`, `RemoteFunction`, or replicated state?"
