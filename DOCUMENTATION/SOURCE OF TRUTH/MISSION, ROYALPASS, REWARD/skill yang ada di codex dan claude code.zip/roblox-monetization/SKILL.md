---
name: roblox-monetization
description: Handle Roblox monetization implementation and policy-aware product design for passes, developer products, subscriptions, paid access, private servers, immersive ads, creator rewards, and payout-related flows. Use when Codex needs help wiring MarketplaceService or ProcessReceipt, choosing the correct product type, restoring entitlements, or answering Indonesian requests about Roblox monetization.
---

# Roblox Monetization

Use this skill when the user is implementing or reviewing Roblox revenue features. Optimize for the correct product type, reliable entitlement handling, and alignment with official Roblox monetization guidance.

## Workflow

1. Identify the monetization surface: pass, developer product, subscription, paid access, private server, ad, or creator reward.
2. Open [references/monetization-playbook.md](references/monetization-playbook.md) for product-selection and entitlement rules.
3. Choose the product type before designing the purchase flow.
4. Explain how the experience prompts, verifies, grants, restores, and persists the entitlement.
5. If the question is mainly about pricing ladders or economy balance, also consult `roblox-economy-design`.

## Working Rules

- Treat purchase prompts as user intent, not proof of entitlement.
- Grant repeatable developer products only after verified server-side receipt handling.
- Restore durable benefits from ownership checks or persisted entitlement state.
- Keep purchase fulfillment idempotent when duplicate receipt handling is possible.
- Use transparent value presentation and avoid manipulative or confusing storefront patterns.
- Verify current monetization product behavior against official Roblox docs when the user asks about current features or platform policy.

## Reference Files

- Read [references/monetization-playbook.md](references/monetization-playbook.md) for product selection, implementation rules, and official doc roots.

## Output Style

- State the chosen Roblox product type first.
- Separate prompt flow, verification flow, entitlement storage, and restore flow.
- Call out where `MarketplaceService`, receipts, and persistence fit into the design.

## Example Requests

- "Should this Roblox item be a pass or a developer product?"
- "How should `ProcessReceipt` grant and save consumables safely?"
- "How do I restore a permanent premium perk on join?"
- "What monetization options fit a Roblox private server feature?"
