# Roblox Monetization Playbook

Use this file when the task is about products, purchase flows, or payout-aware implementation.

## Official Entry Points

- Monetization overview: `https://create.roblox.com/docs/production/monetization`
- Developer products: `https://create.roblox.com/docs/production/monetization/developer-products`
- Subscriptions: `https://create.roblox.com/docs/production/monetization/subscriptions`
- Private servers: `https://create.roblox.com/docs/production/monetization/private-servers`
- Monetization analytics: `https://create.roblox.com/docs/production/analytics/monetization`
- General earning overview: `https://create.roblox.com/docs/get-started/monetization`

## Product Selection

- Pass: durable one-time entitlement within the experience
- Developer product: repeatable consumable or repeat-purchase offering
- Subscription: recurring paid benefit
- Paid access: one-time paywall for entering the experience
- Private server: recurring access to a private session
- Creator rewards or immersive ads: additional monetization surfaces outside direct item ownership

## Implementation Rules

- Finalize benefits on the server, not on the client.
- Keep developer-product fulfillment idempotent because receipt handling can repeat.
- Persist the state needed to restore durable entitlements and repeatable grant history.
- Explain what happens if purchase verification succeeds but saving fails.
- Keep the purchase value proposition explicit so the user understands what they receive.

## Design Rules

- Match product durability to benefit durability.
- Use a mix of durable and repeatable offerings instead of forcing one product type to do everything.
- Avoid aggressive or confusing purchase pressure.
- Keep premium benefits meaningful without making the free experience feel broken.

## Cross-Skill Hand-Offs

- Use `roblox-data-persistence` for receipt storage, entitlement saves, and restore pipelines.
- Use `roblox-economy-design` for pricing ladders, offer mix, analytics targets, and live ops strategy.
