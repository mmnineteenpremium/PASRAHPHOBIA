---
name: roblox-asset-id-manager
description: Use for Roblox asset ID management, asset ownership audits, animation IDs, decal/image IDs, mesh IDs, audio IDs, package IDs, Creator Store IDs, permissions, dependency inventories, migration maps, and replacing or validating asset references in Luau, Rojo projects, Studio objects, or documentation.
---

# Roblox Asset ID Manager

Use this skill when asset references need to be found, verified, renamed, migrated, or documented.

## Workflow

1. Inventory all IDs from scripts, `.project.json`, attributes, configuration modules, UI images, animation objects, sounds, mesh parts, decals, and package links.
2. Classify each ID by type: image, decal, mesh, audio, animation, model, package, place, universe, pass, developer product, badge, avatar item, or Creator Store asset.
3. Confirm owner and usage rights before shipping or uploading derivative work.
4. Build a mapping table with old ID, new ID, type, owner/source, usage location, and status.
5. Replace references only after confirming type compatibility; image IDs and decal IDs are not always interchangeable.
6. Test in Studio with the intended account or group permissions.

## Checks

- Search code with `rg "rbxassetid://|rbxthumb://|assetid|ImageId|TextureID|MeshId|SoundId|AnimationId"`.
- Inspect Studio instances for properties such as `TextureID`, `MeshId`, `SoundId`, `AnimationId`, `Image`, and `LinkedSource`.
- Verify marketplace or Creator Store sources when a third-party asset is used.
- Track private/group-owned assets separately from public assets.
- Confirm moderated, deleted, or private assets have replacements.

## Migration Rules

- Keep a reversible map for asset swaps.
- Do not convert ownership assumptions into hardcoded IDs without documenting source and owner.
- For animations, verify rig compatibility, not just that the ID loads.
- For monetization assets, route to `roblox-monetization` for product/pass IDs and receipt logic.
- For Creator Store publishing, route to `roblox-creator-store`.

## Output Style

- Return a concise asset table when auditing.
- Mark unresolved ownership or permission gaps as blockers.
- Separate code edits, Studio object edits, and Creator Dashboard actions.
