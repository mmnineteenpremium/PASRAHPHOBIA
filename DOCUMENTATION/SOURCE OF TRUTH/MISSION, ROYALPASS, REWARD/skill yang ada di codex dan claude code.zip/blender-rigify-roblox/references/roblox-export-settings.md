# Roblox Export Settings

## Use This File For

- Blender scene scale decisions
- FBX export settings for Roblox Studio
- Importer transform settings to preserve orientation and scale

## Official Sources

- Blender workflow: https://create.roblox.com/docs/art/blender
- Export settings: https://create.roblox.com/docs/art/modeling/export-requirements
- Blender configurations for characters: https://create.roblox.com/docs/art/characters/creating/blender-configurations

## Roblox-Aligned Blender Guidance

- Roblox documentation presents two related scale workflows for `.fbx`:
  - configure the Blender scene for Roblox work with `Length = Centimeters` and `Unit Scale = 0.01`
  - or apply the export-side FBX scaling guidance when the scene is not already configured for Roblox
- Do not stack random scale fixes. Pick one scale strategy and verify it in the Studio import preview.

## Safe FBX Export Defaults

- Export only the selected mesh objects and intended armature.
- Set `Path Mode` to `Copy`.
- Enable `Embed Textures` when you need textures embedded.
- Disable `Add Leaf Bones`.
- Disable `Bake Animation` unless the file intentionally includes animation.

## Scale Handling

- Generic Roblox Blender docs emphasize `Apply Scalings = FBX Unit Scale` to preserve scale between Blender and Studio.
- Roblox export requirement docs for FBX also describe a `.01` scene or export scale workflow.
- If the project already uses Roblox scene scale, keep export scaling simple and consistent.
- If the project does not use Roblox scene scale, follow the current export-side scaling guidance and inspect the importer preview before final import.

## Studio Importer Notes

- In Studio’s importer, use Blender-aligned transform settings:
  - `World Forward = Front`
  - `World Up = Top`
  - `Scale Unit = Stud`
- Use the import preview to catch bad scale or axis issues before committing.
