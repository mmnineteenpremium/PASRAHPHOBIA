# Roblox Rigging Notes

## Use This File For

- Choosing `R1` versus `R15`
- Remembering Studio-side skinning limits
- Checking what Roblox expects from imported rigged meshes

## Official Sources

- Rigging and skinning: https://create.roblox.com/docs/art/modeling/rigging
- Skin a humanoid model: https://create.roblox.com/docs/art/modeling/skin-a-humanoid-model
- Character specifications: https://create.roblox.com/docs/art/characters/specifications
- 3D Importer: https://create.roblox.com/docs/art/modeling/3d-importer

## Distilled Rules

- Roblox supports rigged and skinned meshes imported from third-party tools such as Blender and Maya.
- Studio stores bone influence assignments from the imported mesh asset data.
- `R1` is appropriate for single-mesh skinned assets such as props, creatures, trees, or simple NPCs.
- `R15` is the Roblox humanoid standard for avatars and humanoid characters.
- `R15` means a specific humanoid structure, not just "a rig with fifteen-ish bones".
- Studio does not support more than `4` bone influences on a single vertex.
- For humanoid rigs, do not paint influences onto `Root` or `HumanoidRootNode`; Studio drops those influences on import.
- Bone-driven deformation affects the rendered appearance, not collision shape.

## Practical Implications

- If the target is a player avatar, optimize for clean `R15` compatibility first.
- If the target is a non-humanoid animated asset, prefer the simplest custom rig that gives the motion you need.
- Validate imported rigs in Studio before declaring the Blender work finished.
