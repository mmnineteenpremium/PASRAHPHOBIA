# Blender Rigify Notes

## Use This File For

- Remembering what Rigify generates
- Avoiding common FBX export mistakes from Blender
- Deciding when Rigify is a good fit

## Official Sources

- Rigify basic usage: https://docs.blender.org/manual/en/latest/addons/rigging/rigify/basics.html
- Rigify overview: https://docs.blender.org/manual/en/2.81/addons/rigging/rigify.html
- Rigify generated rig features: https://docs.blender.org/manual/en/latest/addons/rigging/rigify/rig_features.html
- Blender FBX manual: https://docs.blender.org/manual/en/latest/addons/import_export/scene_fbx.html

## Distilled Rules

- Rigify uses a meta-rig workflow: place a meta-rig, then generate the final rig.
- Rigify generation creates controls, mechanics, deformation bones, and widgets.
- The generated rig is an animation-friendly authoring rig, not automatically the ideal game export skeleton.
- Keep the meta-rig and generated rig so future proportion or control changes stay manageable.
- Blender’s FBX workflow has armature and bone-orientation caveats; imported bone orientation can require adjustment.

## Roblox-Specific Interpretation

- Export the clean deform result, not viewport widgets or helper clutter.
- For standard humanoids, Rigify can accelerate authoring, but the final Roblox-facing skeleton must remain simple and predictable.
- For extreme stylization, creatures, or partial rigs, custom bone chains are often cleaner than forcing full Rigify Human.

## When To Avoid Full Rigify

- The model is not a standard humanoid.
- The model only needs a few bending zones.
- The target is a prop, creature, cape, or accessory-like mesh.
- The imported FBX already has a usable deform skeleton and adding a second control rig would only create export noise.
