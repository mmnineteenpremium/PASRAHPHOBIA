---
name: blender-rigify-roblox
description: Rig, skin, clean up, and export `.fbx` character models for Roblox using Blender and Rigify. Use when Codex needs to turn unrigged or badly rigged FBX humanoids into Roblox-ready rigs, choose between `R1` and `R15` targets, rebuild a cleaner deform skeleton for Studio import, fix weight painting issues for skinned meshes, or prepare Blender FBX export/import settings for Roblox.
---

# Blender Rigify Roblox

## Overview

Use this skill for Blender-side character rigging work that ends in Roblox Studio. Prefer a simple Roblox-safe export rig even if Blender uses a richer Rigify control rig for authoring.

## Routing Rule

Blender is the cleanup/rigging/export fallback, not the first generator for Roblox assets. For new 3D model creation, first generate a Google Nano Banana reference image, then prefer Roblox Studio MCP, then Cube3D local, then Tripo3D if available/requested, and use Blender for cleanup, retopology, rigging, skinning, or when the user explicitly asks for Blender.

## Decision Tree

Choose the target before touching bones:

- Use `R15` if the model is a humanoid player character, wearable avatar body, or an NPC that should behave like a standard Roblox character.
- Use `R1` or another custom single-mesh skinned rig if the asset is a creature, prop, tree, cape, tail, or non-avatar animated model. Roblox supports rigged meshes beyond humanoids, but you do not get the full R15 avatar pipeline.
- Use `Rigify Human` or `Basic Human` only when the mesh is close to a standard humanoid. For off-model creatures, partial humanoids, or stylized bodies with extreme proportions, build a simpler custom deform rig instead of forcing full Rigify.

## Workflow

### 1. Intake the FBX

- Inspect whether the FBX already contains an armature, animations, or only a mesh.
- If the imported FBX skeleton is messy, game-agnostic, or clearly not Roblox-oriented, rebuild instead of trying to preserve every original control.
- Separate these cases early:
  - clean humanoid mesh, no rig
  - humanoid mesh with bad rig but salvageable skin weights
  - non-humanoid mesh that only needs a few deformation bones
  - Roblox avatar target that must map cleanly to `R15`
- Keep notes on mesh count, symmetry quality, finger count, face requirements, and whether the model needs only posing or a reusable animation rig.

### 2. Normalize the Blender Scene

- Read [references/roblox-export-settings.md](references/roblox-export-settings.md) before committing to scene scale.
- Prefer a Roblox-oriented Blender setup with centimeters and `0.01` scene scale when doing repeated Roblox work.
- Apply object transforms before rigging. A mismatched object scale will create avoidable export and weight problems.
- If the imported FBX comes in with odd orientation or scale, fix the mesh and armature in Blender before building controls.

### 3. Build the Authoring Rig

- For standard humanoids:
  - Add a Rigify human meta-rig.
  - Fit the meta-rig to the mesh in Edit Mode.
  - Generate the rig only after proportions and joint pivots are defensible.
- For simpler Roblox NPCs:
  - Prefer the smallest rig that gets the motion you need.
  - Do not add film-style control complexity if Roblox will only consume the deform result.
- Remember that Rigify creates controls, mechanisms, deform bones, and widgets. The export target is not the viewport control rig; it is the clean deform result.
- Keep the meta-rig and generated rig in the file. Do not destroy them casually after generation; rework is common.

### 4. Create the Export Rig Mental Model

- Distinguish authoring rig from export rig:
  - authoring rig: animator-friendly controls, widgets, IK/FK helpers
  - export rig: only the bones Roblox actually needs
- Do not export Rigify widgets or helper objects.
- Do not assume every generated bone belongs in Roblox.
- If needed, duplicate or simplify the deformation armature so Studio receives a predictable skeleton instead of Blender-specific control clutter.
- For Roblox humanoids, keep the target compatible with `R15` expectations rather than Blender naming convenience. Read [references/roblox-rigging-notes.md](references/roblox-rigging-notes.md) before finalizing the skeleton.

### 5. Skin and Weight the Mesh

- Enable Auto Normalize while weight painting humanoids.
- Test shoulder, elbow, hip, and knee bends while painting. Roblox errors are often visible in extreme poses before export.
- For Roblox humanoids:
  - Do not weight `Root` or `HumanoidRootNode`.
  - Keep each vertex at `4` bone influences or fewer.
- Prioritize stable deformations over dense bone counts. Roblox is not the place for unnecessary corrective complexity.
- If the imported mesh is split into many parts, be explicit about which meshes are skinned to which bones. R15 expects a disciplined structure.

### 6. Export to FBX for Roblox

- Read [references/roblox-export-settings.md](references/roblox-export-settings.md) and use one scale strategy consistently.
- Minimum safe defaults for Roblox FBX export:
  - export only selected mesh objects and the intended armature
  - `Path Mode = Copy`
  - `Embed Textures = on` when needed
  - `Add Leaf Bones = off`
  - `Bake Animation = off` unless you are intentionally exporting animation data
- If the project is not already using Roblox scene scale, use the export-side scaling guidance from the reference file instead of stacking multiple scale corrections.
- After export, import into Studio with Roblox’s Blender-aligned transform settings and inspect the preview before committing.

### 7. Validate in Roblox Studio

- Verify scale, orientation, bone placement, and mesh segmentation in the importer preview.
- For rigged models, check that Studio recognizes the bones and imported skinning data.
- For humanoids, verify the model is actually usable as the intended `R15` structure, not just visually similar.
- If Studio drops influences or the deformation looks wrong, go back to Blender first. Do not paper over a bad rig in Studio.

## Practical Rules

- Rebuilding a clean deform skeleton is usually faster than trying to rescue an arbitrary marketplace or scan rig.
- Rigify is an authoring convenience, not the final contract with Roblox.
- For a backlog of many FBXs, standardize on one intake checklist and one export profile so results stay consistent.
- If a mesh is non-humanoid, stop forcing an R15 solution unless the user explicitly wants avatar compatibility.
- If facial rigs, FACS, or layered accessories come up, consult the Roblox character references before improvising.

## References

- Use [references/roblox-rigging-notes.md](references/roblox-rigging-notes.md) for Roblox-side rig classes, skinning limits, and Studio import expectations.
- Use [references/roblox-export-settings.md](references/roblox-export-settings.md) for current Blender-to-Roblox scale and FBX export settings.
- Use [references/blender-rigify-notes.md](references/blender-rigify-notes.md) for Rigify-specific reminders and FBX caveats.

## Example Requests

- "Rig this humanoid FBX for Roblox R15 in Blender."
- "Clean up this FBX skeleton and export a Roblox-safe armature."
- "Use Rigify for this character but keep the final FBX clean for Roblox."
- "Fix the weight painting so Studio stops dropping influences."
- "Tell me whether this model should be R1 or R15 before I rig it."
