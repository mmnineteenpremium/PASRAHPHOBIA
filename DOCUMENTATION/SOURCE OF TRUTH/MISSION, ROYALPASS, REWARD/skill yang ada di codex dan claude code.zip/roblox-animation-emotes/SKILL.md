---
name: roblox-animation-emotes
description: Use for Roblox Animation Editor, importing FBX animations, retargeting, R15/R6 compatibility, emote creation, animation asset IDs, Animator/Humanoid playback, emote wheel integration, animation priority, replication boundaries, and troubleshooting broken Roblox animations or emotes.
---

# Roblox Animation Emotes

Use this skill for animation asset creation, import, validation, and runtime integration.

## Tool Priority

- Prefer Roblox Studio tooling and Animation Editor for Roblox animation authoring/import/validation.
- Use Blender when Studio tooling is insufficient, when FBX cleanup is required, or when the user explicitly requests Blender.
- For animated generated models, require named rig-ready components/joints from the 3D generation step before authoring idle/walk/interact clips.

## Workflow

1. Identify rig type: R15, R6, custom skinned mesh, NPC, or avatar body.
2. Decide output: gameplay animation, idle/walk/run set, cutscene, emote, facial/pose animation, or Marketplace avatar emote.
3. Create or import in Animation Editor, then validate on the exact target rig.
4. Export/upload animation and record the asset ID with `roblox-asset-id-manager`.
5. Integrate playback through `Animator`, `AnimationTrack`, priorities, and server/client boundaries appropriate to the use case.
6. Test replication, interruption, looping, blending, and mobile controls.

## Emote Rules

- Confirm current Roblox requirements before publishing an emote as an avatar item.
- Validate that the animation reads clearly without relying on tiny hand or face details.
- Avoid motions that break accessories, layered clothing, or body scale variants.
- Keep gameplay-critical animation state server-authoritative when it affects hitboxes, damage, or rewards.

## Debugging

- Wrong rig type: verify animation was authored for the target skeleton.
- Animation does not play: check asset ownership, permissions, `Animator` location, load timing, and priority.
- Bad blend: inspect animation priority, loop settings, keyframes, and track stop/fade times.
- Not visible to others: determine whether the animation is cosmetic client-only or a replicated gameplay state.

## Output Style

- State the rig type and intended playback context first.
- Separate asset authoring, upload, ID management, and runtime playback.
- Include a small Studio playtest checklist for every emote or animation set.
